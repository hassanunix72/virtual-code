
import SlidingImage from "./components/SlidingImage"
import About from "./pages/About/About"
import Header from "./pages/Home/Header/Header"
import Home from "./pages/Home/Home"

import SectionCollection from "./pages/Home/SectionCollection/SectionCollection"
import Portfolio from "./pages/Portfolio/Portfolio"
import Services from "./pages/Services/Services"
import portfolioSection from "./assets/Rectangle 16.svg"
import { Box } from "@mui/material"
import FAQ from "./pages/FAQ/FAQ"
import Blog from "./pages/Blog/Blog"
import Contact from "./pages/Contact/Contact"
import PricePlanSection from "./pages/Price/PricePlanSection"
import { RouterProvider, createBrowserRouter } from "react-router-dom"
import Navbar from "./pages/Home/Navbar/Navber"

function App() {
  const router = createBrowserRouter([
    {
      path: "/",
      element: <>  <Home /></>
    },
    {
      path: "/about",
      element: <><About /></>
    },
    {
      path: "/services",
      element: <><Services /></>
    },

    {
      path: "/portfolio",
      element: <><Portfolio /></>
    },
    {
      path: "/packages",
      element: <><PricePlanSection /></>
    },
    {
      path: "/contact",
      element: <><Contact /></>
    },

  ])

  return (
    <>

      <RouterProvider router={router} />
      {/* <Home /> */}
      {/* <About /> */}
      {/* <Services /> */}
      {/* <Portfolio /> */}
      {/* <FAQ /> */}
      {/* <Blog /> */}
      {/* <Contact /> */}
      {/* <PricePlanSection /> */}
    </>
  )
}

export default App
