import React from 'react'
import './SlidingImage.css';
import { Box, Grid, IconButton, Typography } from '@mui/material';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import portfolioSection from ".././assets/Rectangle 16.svg"
const SlidingImage = () => {
    return (
        <Box className="image-card" >
            <img src={portfolioSection} alt="Overlay Example" className="image" />
            <Box className="overlay">
                <Box sx={{ marginLeft: "-10px", }}>
                    <Box className="icon-bg">
                        <IconButton>  <ArrowForwardIcon sx={{color:"white"}}/></IconButton>
                    </Box>
                </Box>
                <Typography variant='p' className="overlay-text" sx={{ fontSize: "900" }}>Mobile App</Typography>
            </Box>
        </Box>
    )
}

export default SlidingImage
