import { Box, Typography } from '@mui/material'
import React from 'react'
import Navbar from '../Home/Navbar/Navber'
import AddHomeOutlinedIcon from '@mui/icons-material/AddHomeOutlined';
import ExperienceSection from './ExperienceSection/ExperienceSection';
import CounterSection from '../Home/CounterSection/CounterSection';
import Footer from '../Home/Footer/Footer';
import ContactSection from '../Home/ContactSection/ContactSection';
import TeamSection from './TeamSection/TeamSection';
import AboutContact from './TeamSection/AboutContact';
import BlogSection from './TeamSection/BlogSection';
import "./About.css"

const About = () => {
    return (
        <>
            <Box sx={{ bgcolor: "#181757" }} >
                <Box className="main3-bg" sx={{ height: { lg: "65vh", xs: "80%", md: "40vh" }, paddingBottom: "10px" }}>
                    <Box><Navbar /></Box>
                    <Box sx={{ textAlign: "center", marginY: "160px" }}>

                        <Typography variant='h3' sx={{ fontWeight: "bold", color: "white", fontSize: { lg: "28px", md: "26px", sm: "22px", xs: "18px" } }}>About Us</Typography>
                        <Typography variant='p' sx={{ fontWeight: "bold", color: "white", display: "flex", justifyContent: "center", alignItems: "center" }}><AddHomeOutlinedIcon sx={{ marginBottom: "3px", marginRight: "3px" }} /> Home / <span style={{ marginLeft: "3px", color: "#09aff4" }}>About Us</span></Typography>

                    </Box>
                </Box>

                {/* Components */}
                <Box sx={{ bgcolor: "#181757", paddingY: { lg: "50px", sm: "50px", md: "60px", xs: "30px" } }}>
                    <ExperienceSection />

                </Box>
                <Box sx={{ paddingY: { lg: "80px", sm: "50px", md: "60px", xs: "30px" } }}>
                    <CounterSection />
                </Box>
                <Box><TeamSection /></Box>
                <Box sx={{ paddingY: { lg: "80px", sm: "50px", md: "60px", xs: "30px" } }}>
                    <AboutContact />
                </Box>
                <Box sx={{ paddingY: "10px" }}>
                    <BlogSection />
                </Box>
                <Box>
                    <ContactSection />
                </Box>
                <Box>
                    <Footer />
                </Box>
            </Box >
        </>
    )
}

export default About
