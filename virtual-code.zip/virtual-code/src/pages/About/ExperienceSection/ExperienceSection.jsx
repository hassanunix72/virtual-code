import { Box, Button, Grid, Typography } from '@mui/material'
import React from 'react'
import freeplan from "../../../assets/freeplan.svg"
import aboutfont from "../../../assets/about-font 1.svg"

const ExperienceSection = () => {
    return (
        <Box sx={{ color: "white", padding: { xs: "20px", md: "40px" } }}>
            <Typography
                variant='h5'
                sx={{
                    display: "flex",
                    justifyContent: "center",
                    color: "#09aff4",
                    fontWeight: "bold",
                    fontSize: { xs: "18px", md: "22px" },
                    marginBottom: { xs: "20px", md: "40px" }
                }}
            >
                <Box component="span" sx={{ fontSize: { xs: "18px", md: "22px" }, margin: "0 3px" }}>•</Box>
                ABOUT US
                <Box component="span" sx={{ fontSize: { xs: "18px", md: "22px" }, margin: "0 3px" }}>•</Box>
            </Typography>
            <Grid container justifyContent="center" spacing={4}>
                {/* Left Side */}
                <Grid item lg={4} md={6} sm={11} xs={12}>
                    <Box>
                        <Typography
                            variant='h3'
                            sx={{
                                fontWeight: "bold",
                                fontSize: { xs: "24px", sm: "38px", md: "36px" },
                                marginBottom: "20px"
                            }}
                        >
                            Trusted By Worldwide Clients Since <Box component="span" sx={{ color: "#09aff4" }}>1980</Box>
                        </Typography>
                        <Typography
                            variant='body1'
                            sx={{
                                fontWeight: "bold",
                                fontSize: { xs: "14px", md: "16px" },
                                marginBottom: "40px"
                            }}
                        >
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. A officia molestiae dolorum tempora ut accusamus cupiditate! Nesciunt tempora reiciendis libero voluptate!
                        </Typography>
                        <Grid container spacing={4}>
                            {[...Array(4)].map((_, index) => (
                                <Grid item lg={12} sm={6} xs={12} key={index} sx={{ display: "flex", alignItems: "center" }}>
                                    <Box sx={{ marginRight: "10px", marginBottom: "20px" }}>
                                        <img src={freeplan} alt="Experience icon" />
                                    </Box>
                                    <Box>
                                        <Typography
                                            variant='h5'
                                            sx={{
                                                fontSize: { xs: "18px", md: "22px" },
                                                fontWeight: "bold",
                                                lineHeight: "40px"
                                            }}
                                        >
                                            Experience
                                        </Typography>
                                        <Typography
                                            variant='body2'
                                            sx={{
                                                fontSize: { xs: "12px", md: "14px" }
                                            }}
                                        >
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit. A officia
                                        </Typography>
                                    </Box>
                                </Grid>
                            ))}
                        </Grid>
                        <Box sx={{ marginTop: "40px" }}>
                            <Button
                                sx={{
                                    border: "2px solid rgb(72, 172, 213)",
                                    color: "#09aff4",
                                    borderRadius: "0 10px",
                                    fontSize: { xs: "14px", md: "16px" },
                                    fontWeight: "700",
                                    width: "fit-content",
                                    height: "45px",
                                    "&:hover": { border: "2px solid white", color: "white" }
                                }}
                            >
                                Get In Touch
                            </Button>
                        </Box>
                    </Box>
                </Grid>

                {/* Right Side */}
                <Grid item lg={4} md={6} xs={12} sx={{ display: "flex", justifyContent: "center", marginTop: { xs: "20px", md: "50px" } }}>
                    <Box component="img" src={aboutfont} alt="About font" sx={{ width: "100%", maxWidth: "95%" }} />
                </Grid>
            </Grid>
        </Box>
    )
}

export default ExperienceSection
