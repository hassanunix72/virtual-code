import { Box, Button, Container, Typography } from '@mui/material'
import React from 'react'

const AboutContact = () => {
    return (
        <Box className="main2-bg" sx={{ paddingTop: "80px", color: "white", textAlign: "center" }}>
            <Container maxWidth={"md"}>
                <Typography variant='h6' sx={{ color: "#09aff4", fontWeight: "bold", display: "flex", justifyContent: "center", alignItems: "center", fontSize: "18px" }}>
                    <span style={{ fontSize: "25px", marginRight: "4px" }}>•</span>
                    WANT TO WORK WITH US?
                    <span style={{ fontSize: "25px", marginLeft: "4px" }}>•</span>
                </Typography>
                <Typography variant='h5' sx={{ fontWeight: "bold" }}>Digitally Transform & Grow Your Business</Typography>
                <Typography variant='p' sx={{ fontWeight: "400" }}>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud consectetur voluptatem accusantium doloremque adipiscing elit.
                </Typography>
                <Box sx={{ marginY: "60px" }}>
                    <Button sx={{ border: "3px solid rgb(72, 172, 213)", marginRight: "45px", paddingX: "15px", color: "#09aff4", borderRadius: "0 10px", textTransform: "capitalize", fontSize: "18px", fontWeight: "700", width: "fit-content", height: "50px", "&:hover": { border: "2px solid white", color: "white" } }}>Call Now</Button>
                    <Button sx={{ border: "3px solid rgb(72, 172, 213)", paddingX: "15px", color: "#09aff4", borderRadius: "0 10px", textTransform: "capitalize", fontSize: "18px", fontWeight: "700", width: "fit-content", height: "50px", "&:hover": { border: "2px solid white", color: "white" } }}>Contact Us</Button>

                </Box>

            </Container>

        </Box>
    )
}

export default AboutContact
