import { Box, Typography } from '@mui/material'
import React from 'react'

import BookmarkBorderOutlinedIcon from '@mui/icons-material/BookmarkBorderOutlined';
import PersonOutlineOutlinedIcon from '@mui/icons-material/PersonOutlineOutlined';

const BlogCards = ({ src, className }) => {
    return (
        <Box className={className} sx={{
            height: { lg: "520.969px", xs: "100%" },
            width: { lg: "440px", xs: "100%" },
            borderRadius: "6px",
            border: "1px solid rgb(13, 202, 240)",
            mx: "auto",
            overflow: "hidden",
            color: "white"
        }}>
            <Typography component={"img"} src={src} sx={{
                width: { lg: "440px", xs: "100%" },
                height: "auto",
                maxWidth: "100%"
            }} />
            <Box sx={{
                textAlign: "start",
                m: "15px",
                width: { lg: "90%", xs: "100%" },

            }}>
                <Typography variant='body1' sx={{
                    display: "flex",
                    justifyContent: "start",
                    alignItems: "center",
                    gap: "5px"
                }}>
                    <BookmarkBorderOutlinedIcon /> Hosting | <PersonOutlineOutlinedIcon /> Jhon Doe
                </Typography>
                <Box sx={{ mt: "20px" }}>
                    <Typography variant="h4" sx={{
                        fontWeight: "bold",
                        fontSize: { lg: "24px", xs: "20px" }
                    }}>
                        How Litespeed Tech Works To Speed Up Your Site
                    </Typography>
                    <Box sx={{ mt: "20px" }}>
                        <Typography variant="body2">
                            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Iure nulla dolorem, voluptates molestiae
                        </Typography>
                    </Box>
                    <Box sx={{ mt: "20px" }}>
                        <Typography variant="body2" sx={{
                            fontWeight: "bold",
                            color: "#09aff4"
                        }}>
                            Read More
                        </Typography>
                    </Box>
                </Box>
            </Box>
        </Box>
    )
}

export default BlogCards;
