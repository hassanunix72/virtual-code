import { Box, Container, Grid, Typography } from '@mui/material'
import React from 'react'
import BlogCards from './BlogCards'
import bloglogo from "../../../assets/bloglogo.svg"
const BlogSection = () => {
    return (
        <Box sx={{ color: "white", textAlign: "center" }}>
            <Typography
                variant='h6'
                sx={{
                    color: "#09aff4",
                    fontWeight: "bold",
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    fontSize: { xs: "18px", md: "22px" }
                }}
            >
                <Box
                    component="span"
                    sx={{
                        fontSize: { xs: "20px", md: "25px" },
                        marginRight: "4px"
                    }}
                >
                    •
                </Box>
                BLOGS
                <Box
                    component="span"
                    sx={{
                        fontSize: { xs: "20px", md: "25px" },
                        marginLeft: "4px"
                    }}
                >
                    •
                </Box>
            </Typography>
            <Typography
                variant='h3'
                sx={{
                    fontWeight: "bold",
                    fontSize: { xs: "24px", md: "36px", lg: "42px" },
                    marginY: { xs: "10px", md: "15px" }
                }}>
                Latest News
            </Typography>

            <Container maxWidth={"xl"}>
                <Grid container sx={{ marginY: "40px" }}>
                    <Grid item lg={4} md={12} xs={12} sm={12}><Box sx={{ marginY: "20px" }}><BlogCards src={bloglogo} /></Box></Grid>
                    <Grid item lg={4} md={12} xs={12} sm={12}><Box sx={{ marginY: "20px" }}><BlogCards src={bloglogo} /></Box></Grid>
                    <Grid item lg={4} md={12} xs={12} sm={12}><Box sx={{ marginY: "20px" }}><BlogCards src={bloglogo} /></Box></Grid>
                </Grid>
            </Container>
        </Box>
    )
}

export default BlogSection
