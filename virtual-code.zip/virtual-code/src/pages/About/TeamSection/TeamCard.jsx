import { Box, Typography } from '@mui/material'
import React from 'react'
import teamlogo from "../../../assets/teamlogo.svg"
const TeamCard = () => {
    return (
        <Box sx={{ lineHeight: "22px" }}>
            <Typography component={"img"} src={teamlogo} sx={{ width: "306px", maxWidth: "100%" }} />
            <br />
            <br />
            <Typography variant='p'>Jhon Doe</Typography>
            <br />
            <Typography variant='p' sx={{ fontSize: "14px", marginTop: "20px" }}>co Founder</Typography>
        </Box>
    )
}

export default TeamCard
