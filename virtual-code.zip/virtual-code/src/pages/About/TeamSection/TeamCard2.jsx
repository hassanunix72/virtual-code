import { Box, Button, Container } from '@mui/material'
import React from 'react'
import CustomPlanLogo from '../../../components/CustomLogo/CustomPlanLogo'
import "../../Home/PriceSection/PriceSection.css"
const TeamCard2 = ({ headingLabel }) => {
    return (
        <Container >


            <Box className="custom_card_01" sx={{
                border: "2px solid #09aff4",
                height: { lg: "50%", xs: "90%" },
                width: { lg: "350px", },
                textAlign: "start",
                borderRadius: "5px",


            }}>
                <Container sx={{
                    "p:hover": {
                        color: "white"
                    }
                }}>
                    <Box sx={{ marginTop: "20px" }}> <CustomPlanLogo /></Box>
                    <h2 style={{ margin: "20px 0" }}>
                        {headingLabel}
                    </h2>
                    <p style={{ margin: "20px 0", width: "90%", lineHeight: "25px" }}>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sedarchitecto dolorum inventore totam adipisci</p>

                </Container>
            </Box>

        </Container>
    )
}

export default TeamCard2
