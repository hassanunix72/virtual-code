import { Box, Button, Grid, Typography } from '@mui/material'
import React from 'react'
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import TeamCard from './TeamCard';
import TeamSection2 from './TeamSection2';

const TeamSection = () => {
    return (
        <>
            <Box sx={{ color: "white", textAlign: "center" }}>
                <Grid container justifyContent="center" >
                    <Grid item lg={6} >

                        <Typography variant='h6' sx={{ color: "#09aff4", fontWeight: "bold", display: "flex", justifyContent: "center", alignItems: "center" }}>
                            <span style={{ fontSize: "25px", marginRight: "4px" }}>•</span>
                            Our Services
                            <span style={{ fontSize: "25px", marginLeft: "4px" }}>•</span>
                        </Typography>


                        <Typography variant='h3' sx={{ fontWeight: "700", margin: "10px 0", fontSize: { lg: "48px", sm: "30px", xs: "25px", md: "48px" } }}>

                            Our Expert Team Members

                        </Typography>

                    </Grid>


                    <Grid item lg={1} xs={12} sx={{ marginTop: { lg: "60px", xs: "10px" }, paddingLeft: { lg: "65px", xs: "0" } }}>
                        <Button
                            sx={{
                                border: "2px solid rgb(72, 172, 213)",
                                color: "#09aff4",
                                borderRadius: "0 10px",
                                fontSize: { lg: "16px", md: "16px", sm: "15px", xs: "10px" },
                                fontWeight: "bold",
                                width: { lg: "150px", sm: "200px", xs: "100px" },
                                margin: { lg: "0 20px", xs: "0" },
                                height: { lg: "50px", sm: "60px", xs: "40px" },
                                "&:hover": {
                                    border: "2px solid white",
                                    color: "white"
                                }
                            }}
                        >
                            See More
                            <ArrowForwardIcon
                                sx={{
                                    marginBottom: { lg: "3px", sm: "3px", xs: "2px" },
                                    fontSize: { lg: "22px", sm: "18px", xs: "16px" }
                                }}
                            />
                        </Button>
                    </Grid>
                </Grid>
                <Box sx={{ marginTop: "30px" }}>
                    <Grid container justifyContent="center" spacing={3}>
                        <Grid item lg={2}>
                            <Box> <TeamCard /></Box>
                        </Grid>
                        <Grid item lg={2}>
                            <Box> <TeamCard /></Box>
                        </Grid>
                        <Grid item lg={2}>
                            <Box> <TeamCard /></Box>
                        </Grid>
                        <Grid item lg={2}>
                            <Box> <TeamCard /></Box>
                        </Grid>
                    </Grid>
                </Box>
                <Box sx={{ paddingY: "40px" }}>
                    <TeamSection2 />
                </Box>

            </Box>
        </>
    )
}

export default TeamSection
