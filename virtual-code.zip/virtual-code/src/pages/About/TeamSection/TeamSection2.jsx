import { Box, Container, Grid, Typography } from '@mui/material'
import React from 'react'
import TeamCard2 from './TeamCard2'
import "../../Home/PriceSection/PriceSection.css"
const TeamSection2 = () => {
    return (
        <Box>
            <Grid container justifyContent="center" >
                <Grid item lg={6} >

                    <Typography variant='h6' sx={{ color: "#09aff4", fontWeight: "bold", display: "flex", justifyContent: "center", alignItems: "center", fontSize: "18px" }}>
                        <span style={{ fontSize: "20px", marginRight: "4px" }}>•</span>
                        4 STEP WORKING PRCOESS
                        <span style={{ fontSize: "20px", marginLeft: "4px" }}>•</span>
                    </Typography>


                    <Typography variant='h3' sx={{ fontWeight: "700", margin: "10px 0", fontSize: { lg: "48px", sm: "30px", xs: "25px", md: "48px" } }}>
                        Working Process
                    </Typography>

                </Grid>

            </Grid>
            <Container maxWidth={"xl"} sx={{ marginY: "30px" }}>
                <Grid container >
                    <Grid item lg={3} xs={12} sm={12} md={12} className='plan-logo'>
                        <Box sx={{ marginY: "30px" }}><TeamCard2 headingLabel={"Discover"} /></Box>
                    </Grid>
                    <Grid item lg={3} xs={12} sm={12} md={12} className='plan-logo'>
                        <Box sx={{ marginY: "30px" }}><TeamCard2 headingLabel={"Design & Development"} /></Box>
                    </Grid>
                    <Grid item lg={3} xs={12} sm={12} md={12} className='plan-logo'>
                        <Box sx={{ marginY: "30px" }}><TeamCard2 headingLabel={"Install & Testing"} /></Box>
                    </Grid>
                    <Grid item lg={3} xs={12} sm={12} md={12} className='plan-logo'>
                        <Box sx={{ marginY: "30px" }}><TeamCard2 headingLabel={"Project Delivery"} /></Box>
                    </Grid>
                </Grid>
            </Container>
        </Box>
    )
}

export default TeamSection2
