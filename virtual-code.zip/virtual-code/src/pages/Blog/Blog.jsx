import { Box, Container, Grid, Typography } from '@mui/material'
import React from 'react'
import Navbar from '../Home/Navbar/Navber'
import AddHomeOutlinedIcon from '@mui/icons-material/AddHomeOutlined';


import "./Blog.css"
import BlogCollection from './BlogCollection';
import BlogCollection2 from './BlogCollection2';
import BlogCollection3 from './BlogCollection3';
import Footer from '../Home/Footer/Footer';
const Blog = () => {
    return (
        <Box sx={{ bgcolor: "#181757" }} >
            <Box className="main3-bg" sx={{ height: { lg: "65vh", xs: "80%", md: "40vh" }, paddingBottom: "10px" }}>
                <Box>
                    <Navbar />
                </Box>
                <Box sx={{ textAlign: "center", marginY: "160px" }}>

                    <Typography variant='h3' sx={{ fontWeight: "700", color: "white", fontSize: { lg: "48px", md: "26px", sm: "22px", xs: "18px" } }}>Blogs</Typography>
                    <Typography variant='p' sx={{ fontWeight: "600", color: "white", display: "flex", justifyContent: "center", alignItems: "center" }}><AddHomeOutlinedIcon sx={{ marginBottom: "3px", marginRight: "3px" }} /> Home / <span style={{ marginLeft: "4px", color: "#09aff4" }}>blog</span></Typography>

                </Box>
            </Box>
            <Box sx={{ paddingY: "40px" }}>
                <Container maxWidth={"xl"}>
                    <Grid container justifyContent={"center"} >
                        <Grid item lg={8} md={12}>
                            <BlogCollection />
                        </Grid>
                        <Grid item lg={4} sx={{ marginTop: "30px" }}>
                            <Box>
                                <BlogCollection2 />
                            </Box>
                            <Box>
                                <BlogCollection3 />
                            </Box>
                        </Grid>
                    </Grid>
                </Container>
            </Box>
            <Box>
                <Footer />
            </Box>
        </Box>
    )
}

export default Blog
