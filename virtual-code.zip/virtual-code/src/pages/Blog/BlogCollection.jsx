import { Box, Button, Container, Grid } from '@mui/material'
import React from 'react'
import BlogCards from '../About/TeamSection/BlogCards'
import bloglogo from "../../assets/blog-image.svg"
import ArrowBackIosOutlinedIcon from '@mui/icons-material/ArrowBackIosOutlined';
import ArrowForwardIosOutlinedIcon from '@mui/icons-material/ArrowForwardIosOutlined';
const BlogCollection = () => {
    return (
        <Box>
            <Container>
                <Grid container maxWidth={"md"} spacing={{ lg: 1, sm: 2, xs: 2 }}>
                    <Grid item lg={6} md={6} xs={12}>
                        <BlogCards src={bloglogo} className='custom_card_01' />
                    </Grid>
                    <Grid item lg={6} md={6} xs={12}>
                        <BlogCards src={bloglogo} className='custom_card_01' />
                    </Grid>
                    <Grid item lg={6} md={6} xs={12}>
                        <BlogCards src={bloglogo} className='custom_card_01' />
                    </Grid>
                    <Grid item lg={6} md={6} xs={12}>
                        <BlogCards src={bloglogo} className='custom_card_01' />
                    </Grid>
                </Grid>
            </Container>
            <Box
                sx={{
                    display: 'flex',
                    justifyContent: 'center',
                    flexWrap: 'wrap',
                    marginY: '30px',
                    gap: '10px', // Space between buttons
                }}
            >
                <Button
                    sx={{
                        color: 'white',
                        border: '2px solid #09aff4',
                        borderRadius: '6px',
                        '&:hover': { backgroundColor: '#09aff4' },
                        padding: { xs: '5px', sm: '10px', md: '15px' },
                        minWidth: { xs: '30px', sm: '40px', md: '50px' }, // Adjust the width for different screen sizes
                    }}
                >
                    <ArrowBackIosOutlinedIcon />
                </Button>
                {[1, 2, 3, 4, 5].map((number) => (
                    <Button
                        key={number}
                        sx={{
                            color: 'white',
                            border: '2px solid #09aff4',
                            borderRadius: '6px',
                            '&:hover': { backgroundColor: '#09aff4' },
                            padding: { xs: '5px', sm: '10px', md: '15px' },
                            minWidth: { xs: '30px', sm: '40px', md: '50px' }, // Adjust the width for different screen sizes
                        }}
                    >
                        {number}
                    </Button>
                ))}
                <Button
                    sx={{
                        color: 'white',
                        border: '2px solid #09aff4',
                        borderRadius: '6px',
                        '&:hover': { backgroundColor: '#09aff4' },
                        padding: { xs: '5px', sm: '10px', md: '15px' },
                        minWidth: { xs: '30px', sm: '40px', md: '50px' }, // Adjust the width for different screen sizes
                    }}
                >
                    <ArrowForwardIosOutlinedIcon />
                </Button>
            </Box>
        </Box>
    )
}

export default BlogCollection
