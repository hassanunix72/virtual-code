import { Box, Grid, Typography } from '@mui/material'
import React from 'react'

const BlogCollection2 = () => {
    return (
        <>
            <Box>
                <Typography variant='p' sx={{ fontWeight: "900", fontSize: "18px", color: "white", }}>
                    Popular Post
                </Typography>
                <Box sx={{ borderBottom: "2px solid #09aff4", marginTop: "20px", width: { lg: "80%", xs: "100%" }, }}></Box>

                <Box sx={{ display: "flex", alignItems: "center", color: "white" }}>
                    <Box sx={{ marginY: "15px" }}>
                        <Typography component={"img"} src='https://www.virtualcodes.net/template/assets/images/blogs/77.png' width={"100px"} sx={{ borderRadius: "8px" }} />
                    </Box>
                    <Box sx={{ marginX: "10px" }}>
                        <Typography variant='h6' sx={{ fontWeight: "700", fontSize: "14px" }}>10 April 2024</Typography>
                        <Typography component='p' sx={{ fontSize: "14px" }}>Planning for a Safe Return to the Workplace IT Solution</Typography>
                    </Box>
                </Box>
            </Box>
            <Box>


                <Box sx={{ display: "flex", alignItems: "center", color: "white" }}>
                    <Box sx={{ marginY: "15px" }}>
                        <Typography component={"img"} src='https://www.virtualcodes.net/template/assets/images/blogs/77.png' width={"100px"} sx={{ borderRadius: "8px" }} />
                    </Box>
                    <Box sx={{ marginX: "10px" }}>
                        <Typography variant='h6' sx={{ fontWeight: "700", fontSize: "14px" }}>10 April 2024</Typography>
                        <Typography component='p' sx={{ fontSize: "14px" }}>Planning for a Safe Return to the Workplace IT Solution</Typography>
                    </Box>
                </Box>
            </Box>
            <Box>


                <Box sx={{ display: "flex", alignItems: "center", color: "white" }}>
                    <Box sx={{ marginY: "15px" }}>
                        <Typography component={"img"} src='https://www.virtualcodes.net/template/assets/images/blogs/77.png' width={"100px"} sx={{ borderRadius: "8px" }} />
                    </Box>
                    <Box sx={{ marginX: "10px" }}>
                        <Typography variant='h6' sx={{ fontWeight: "700", fontSize: "14px" }}>10 April 2024</Typography>
                        <Typography component='p' sx={{ fontSize: "14px" }}>Planning for a Safe Return to the Workplace IT Solution</Typography>
                    </Box>
                </Box>
            </Box>
            <Box>


                <Box sx={{ display: "flex", alignItems: "center", color: "white" }}>
                    <Box sx={{ marginY: "15px" }}>
                        <Typography component={"img"} src='https://www.virtualcodes.net/template/assets/images/blogs/77.png' width={"100px"} sx={{ borderRadius: "8px" }} />
                    </Box>
                    <Box sx={{ marginX: "10px" }}>
                        <Typography variant='h6' sx={{ fontWeight: "700", fontSize: "14px" }}>10 April 2024</Typography>
                        <Typography component='p' sx={{ fontSize: "14px" }}>Planning for a Safe Return to the Workplace IT Solution</Typography>
                    </Box>
                </Box>
            </Box>
        </>
    )
}

export default BlogCollection2
