import { Box, Icon, IconButton, Link, Typography } from '@mui/material'
import React from 'react'
import FacebookIcon from '@mui/icons-material/Facebook';
import fbIcon from "../../assets/fb-Icon.svg"
import ytIcon from "../../assets/yt-icon.svg"
import instaIcon from "../../assets/insta-icon.svg"
import twitterIcon from "../../assets/twitter-icon.svg"
const BlogCollection3 = () => {
    return (
        <>
            {/* Category Section Start*/}
            <Box sx={{ color: "white", }}>
                <Typography variant='p' sx={{ fontWeight: "900", fontSize: "18px", color: "white", }}>
                    Categories
                </Typography>
                <Box sx={{ borderBottom: "2px solid #09aff4", marginTop: "20px", width: { lg: "80%", xs: "100%" }, }}></Box>

                <Box className='custom_card_01' sx={{ border: "2px solid #09aff4", marginTop: "20px", padding: "8px 16px", borderRadius: "10px", display: "flex", justifyContent: "space-between", width: { lg: "80%", xs: "100%" } }}>
                    <Typography component={"p"} >Business</Typography>
                    <Typography component={"p"} >17 </Typography>
                </Box>

                <Box className='custom_card_01' sx={{ border: "2px solid #09aff4", marginTop: "20px", padding: "8px 16px", borderRadius: "10px", display: "flex", justifyContent: "space-between", width: { lg: "80%", xs: "100%" } }}>
                    <Typography component={"p"} >Solution</Typography>
                    <Typography component={"p"} >23 </Typography>
                </Box>

                <Box className='custom_card_01' sx={{ border: "2px solid #09aff4", marginTop: "20px", padding: "8px 16px", borderRadius: "10px", display: "flex", justifyContent: "space-between", width: { lg: "80%", xs: "100%" } }}>
                    <Typography component={"p"} >Technology</Typography>
                    <Typography component={"p"} >10 </Typography>
                </Box>

                <Box className='custom_card_01' sx={{ border: "2px solid #09aff4", marginTop: "20px", padding: "8px 16px", borderRadius: "10px", display: "flex", justifyContent: "space-between", width: { lg: "80%", xs: "100%" } }}>
                    <Typography component={"p"} >Digital Marketing</Typography>
                    <Typography component={"p"} >15 </Typography>
                </Box>

                <Box className='custom_card_01' sx={{ border: "2px solid #09aff4", marginTop: "20px", padding: "8px 16px", borderRadius: "10px", display: "flex", justifyContent: "space-between", width: { lg: "80%", xs: "100%" } }}>
                    <Typography component={"p"} >Graphic Design</Typography>
                    <Typography component={"p"} >25 </Typography>
                </Box>
            </Box >

            {/* Category Section End*/}
            <Box sx={{ color: "white", marginTop: "20px", }}>
                <Typography variant='p' sx={{ fontWeight: "900", fontSize: "18px", color: "white", }}>
                    Follow Us On:
                </Typography>
                <Box sx={{ borderBottom: "2px solid #09aff4", marginTop: "20px", width: {lg:"80%",xs:"100%"}, }}></Box>
                <Box sx={{ display: "flex", justifyContent: { lg: "start", xs: "center" }, }}>
                    <Box sx={{ backgroundColor: "#09aff4", width: "fit-content", height: "40px", margin: "10px", borderRadius: "6px", }}>
                        <IconButton >

                            <Typography component={"img"} src={fbIcon} />

                        </IconButton>
                    </Box>
                    <Box sx={{ backgroundColor: "#09aff4", width: "fit-content", height: "40px", margin: "10px", borderRadius: "6px" }}>
                        <IconButton >

                            <Typography component={"img"} src={ytIcon} />

                        </IconButton>
                    </Box>
                    <Box sx={{ backgroundColor: "#09aff4", width: "fit-content", height: "40px", margin: "10px", borderRadius: "6px" }}>
                        <IconButton >

                            <Typography component={"img"} src={instaIcon} />

                        </IconButton>
                    </Box>
                    <Box sx={{ backgroundColor: "#09aff4", width: "fit-content", height: "40px", margin: "10px", borderRadius: "6px", verticalAlign: "middle" }}>
                        <IconButton>

                            <Typography component={"img"} src={twitterIcon} />

                        </IconButton>
                    </Box>

                </Box>
            </Box>
        </>
    )
}

export default BlogCollection3
