import { Box, Typography } from '@mui/material'
import React from 'react'
import Navbar from '../Home/Navbar/Navber'
import AddHomeOutlinedIcon from '@mui/icons-material/AddHomeOutlined';
import OfficeSection from './OfficeSection/OfficeSection';
import QuestionSection from './QuestionSection/QuestionSection';
import Footer from '../Home/Footer/Footer';
const Contact = () => {
    return (
        <Box sx={{ bgcolor: "#181757" }} >
            <Box className="main3-bg" sx={{ height: { lg: "65vh", xs: "80%", md: "40vh" }, paddingBottom: "10px" }}>
                <Box><Navbar /></Box>
                <Box sx={{ textAlign: "center", marginY: "160px" }}>

                    <Typography variant='h3' sx={{ fontWeight: "bold", color: "white", fontSize: { lg: "48px", md: "26px", sm: "22px", xs: "18px" } }}>Contact Us</Typography>
                    <Typography variant='p' sx={{ fontWeight: "bold", color: "white", display: "flex", justifyContent: "center", alignItems: "center" }}><AddHomeOutlinedIcon sx={{ marginBottom: "3px", marginRight: "3px" }} /> Home / <span style={{ marginLeft: "3px", color: "#09aff4" }}>Contact Us</span></Typography>

                </Box>
            </Box>
            <Box sx={{ paddingY: "20px" }}>
                <OfficeSection />
            </Box>
            <Box sx={{ paddingY: "30px" }}>
                <QuestionSection />
            </Box>
            <Box>
                <Footer />
            </Box>
        </Box>
    )
}

export default Contact
