import { Box, Container, Grid, IconButton, Typography } from '@mui/material'
import React from 'react'
import LocalPhoneOutlinedIcon from '@mui/icons-material/LocalPhoneOutlined';
import EmailOutlinedIcon from '@mui/icons-material/EmailOutlined';
const OfficeSection = () => {
    return (
        <Box sx={{ color: "white" }}>
            <Box>
                <Typography variant='h3' sx={{ textAlign: "center", fontSize: "48px", fontWeight: "bold", paddingY: "60px" }}> Our Offices Around The World</Typography>
            </Box>
            <Container maxWidth={"xl"} >
                <Grid container justifyContent={"center"}>
                    <Grid item lg={3} md={5} sm={12} xs={12} sx={{ border: "2px solid #09aff4", borderRadius: "6px", height: "100%", width: "350px", textAlign: "start", marginX: { lg: "25px", md: "10px" }, marginY: { xs: "20px", md: "10px" } }}>
                        <Box sx={{ padding: "24px" }}>
                            <Typography variant='h4' sx={{ fontSize: "24px", fontWeight: "500", }}>
                                New York
                            </Typography>
                            <Typography component={"p"} sx={{ fontSize: "16px", paddingY: "24px" }}>United States, 307 Wilshire, 2nd Av. New York 3516.</Typography>
                            <Box sx={{ display: "flex", alignItems: "center" }}>
                                <Box>
                                    <EmailOutlinedIcon sx={{ fontSize: "58px", color: '#09aff4' }} />
                                </Box>
                                <Box>
                                    <Typography component={"p"} sx={{ fontWeight: "500", }}>
                                        Email
                                    </Typography>
                                    <Typography component={"p"} sx={{ fontWeight: "500", }}>
                                        JohnDoe@gmail.com
                                    </Typography>
                                </Box>
                            </Box>
                            <Box sx={{ display: "flex", alignItems: "center" }}>
                                <Box>
                                    <LocalPhoneOutlinedIcon sx={{ fontSize: "58px", color: '#09aff4' }} />
                                </Box>
                                <Box>
                                    <Typography component={"p"} sx={{ fontWeight: "600", }}>
                                        Phone
                                    </Typography>
                                    <Typography component={"p"} sx={{ fontWeight: "500", }}>
                                        (xxx)(xxx)(xxxx)
                                    </Typography>
                                </Box>
                            </Box>
                        </Box>
                    </Grid>

                    {/* 2nd Box */}
                    <Grid item lg={3} md={5} sm={12} xs={12} sx={{ border: "2px solid #09aff4", borderRadius: "6px", height: "100%", width: "350px", textAlign: "start", marginX: { lg: "25px", md: "10px" }, marginY: { xs: "20px", md: "10px" } }}>
                        <Box sx={{ padding: "24px" }}>
                            <Typography variant='h4' sx={{ fontSize: "24px", fontWeight: "500", }}>
                                New York
                            </Typography>
                            <Typography component={"p"} sx={{ fontSize: "16px", paddingY: "24px" }}>United States, 307 Wilshire, 2nd Av. New York 3516.</Typography>
                            <Box sx={{ display: "flex", alignItems: "center" }}>
                                <Box>
                                    <EmailOutlinedIcon sx={{ fontSize: "58px", color: '#09aff4' }} />
                                </Box>
                                <Box>
                                    <Typography component={"p"} sx={{ fontWeight: "500", }}>
                                        Email
                                    </Typography>
                                    <Typography component={"p"} sx={{ fontWeight: "500", }}>
                                        JohnDoe@gmail.com
                                    </Typography>
                                </Box>
                            </Box>
                            <Box sx={{ display: "flex", alignItems: "center" }}>
                                <Box>
                                    <LocalPhoneOutlinedIcon sx={{ fontSize: "58px", color: '#09aff4' }} />
                                </Box>
                                <Box>
                                    <Typography component={"p"} sx={{ fontWeight: "600", }}>
                                        Phone
                                    </Typography>
                                    <Typography component={"p"} sx={{ fontWeight: "500", }}>
                                        (xxx)(xxx)(xxxx)
                                    </Typography>
                                </Box>
                            </Box>
                        </Box>
                    </Grid>
                    {/* 3rd Box */}

                    <Grid item lg={3} md={5} sm={12} xs={12} sx={{ border: "2px solid #09aff4", borderRadius: "6px", height: "100%", width: "350px", textAlign: "start", marginX: { lg: "25px", md: "10px" }, marginY: { xs: "20px", md: "10px" } }}>
                        <Box sx={{ padding: "24px" }}>
                            <Typography variant='h4' sx={{ fontSize: "24px", fontWeight: "500", }}>
                                New York
                            </Typography>
                            <Typography component={"p"} sx={{ fontSize: "16px", paddingY: "24px" }}>United States, 307 Wilshire, 2nd Av. New York 3516.</Typography>
                            <Box sx={{ display: "flex", alignItems: "center" }}>
                                <Box>
                                    <EmailOutlinedIcon sx={{ fontSize: "58px", color: '#09aff4' }} />
                                </Box>
                                <Box>
                                    <Typography component={"p"} sx={{ fontWeight: "500", }}>
                                        Email
                                    </Typography>
                                    <Typography component={"p"} sx={{ fontWeight: "500", }}>
                                        JohnDoe@gmail.com
                                    </Typography>
                                </Box>
                            </Box>
                            <Box sx={{ display: "flex", alignItems: "center" }}>
                                <Box>
                                    <LocalPhoneOutlinedIcon sx={{ fontSize: "58px", color: '#09aff4' }} />
                                </Box>
                                <Box>
                                    <Typography component={"p"} sx={{ fontWeight: "600", }}>
                                        Phone
                                    </Typography>
                                    <Typography component={"p"} sx={{ fontWeight: "500", }}>
                                        (xxx)(xxx)(xxxx)
                                    </Typography>
                                </Box>
                            </Box>
                        </Box>
                    </Grid>
                </Grid>
            </Container>
        </Box>
    )
}

export default OfficeSection
