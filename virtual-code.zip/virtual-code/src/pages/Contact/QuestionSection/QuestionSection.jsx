import React from 'react'
import { Box, Button, Container, Grid, Typography } from '@mui/material'
const QuestionSection = () => {
    return (
        <Box sx={{ textAlign: "center", color: "white" }}>
            <Typography variant='h6' sx={{ color: "#09aff4", fontWeight: "bold", display: "flex", justifyContent: "center", alignItems: "center" }}>
                <span style={{ fontSize: "25px", marginRight: "4px" }}>•</span>
                LET’S TALK
                <span style={{ fontSize: "25px", marginLeft: "4px" }}>•</span>
            </Typography>


            <Typography variant='h3' sx={{ fontWeight: "700", margin: "10px 0", fontSize: { lg: "48px", xs: "30px", sm: "36px" } }}>Have Any Questions? Let's Answer Them</Typography>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sedarchitecto dolorum inventore totam adipisci</p>

            <Container maxWidth={"md"} sx={{ marginTop: "40px", }}>
                <form>
                    <Grid container spacing={2} >
                        <Grid item lg={6} sm={6} xs={12}>
                            <input
                                type="text"
                                placeholder='First Name*'
                                required
                                className="custom-input"
                            />

                        </Grid>
                        <Grid item lg={6} sm={6} xs={12}>
                            <input
                                type="email"
                                placeholder='Email*'
                                required
                                className="custom-input"
                            />
                        </Grid>
                        <Grid item lg={6} sm={6} xs={12}>
                            <input
                                type="text"
                                placeholder='Phone*'
                                className="custom-input"
                            />
                        </Grid>
                        <Grid item lg={6} sm={6} xs={12} >
                            <input
                                type="text"
                                placeholder='Country*'
                                className="custom-input"
                            />
                        </Grid>
                        <Grid item lg={12} sm={12} xs={12}>
                            <input
                                type="text"
                                placeholder='Im Interested In'
                                className="custom-input"
                            />
                        </Grid>

                        <Grid item lg={12} sm={12} xs={12}>

                            <textarea name="" id="" className="custom-textarea" placeholder='Message'></textarea>
                        </Grid>
                        <Grid item lg={12} sm={12} xs={12}>

                            <Button sx={{ border: "3px solid rgb(72, 172, 213)", color: "#09aff4", borderRadius: "0 10px", textTransform: "capitalize", fontSize: "18px", fontWeight: "700", width: "fit-content", textSizeAdjust: "100%", height: "50px", "&:hover": { border: "2px solid white", color: "white" } }}>Send Your Message</Button>
                        </Grid>
                    </Grid>

                </form>
            </Container>

        </Box>
    )
}

export default QuestionSection
