import { Box, Container, Grid, Typography } from '@mui/material'
import React from 'react'
import "./ContactSection.css"
import email from "../../../assets/email.svg"
import msg from "../../../assets/msg.svg"
import phone from "../../../assets/phone.svg"
const ContactSection2 = () => {
    return (
        <Box className="main-bg3" sx={{ height: { lg: "300px", xs: "700px", } }}>
            <Container maxWidth={"xl"}>
                <Grid container sx={{ textAlign: "start", marginLeft: { lg: "40px", xs: "0" } }} >
                    <Grid item lg={4} xs={12} sx={{ borderLeft: "2px solid #09aff4", height: "200px", marginTop: "50px", paddingLeft: "10px" }}>
                        <Typography variant='h5' sx={{ fontWeight: "700", color: "white", marginTop: "40px", }}>Email</Typography>
                        <Box sx={{ display: "flex", alignItems: "center", marginTop: "20px" }}>
                            <Typography component={"img"} src={email} />
                            <Typography variant='p' sx={{ color: "white", fontWeight: "bold", fontSize: { lg: "15px", xs: "20px" } }}>JhonDoe@gmail.com</Typography>
                        </Box>
                    </Grid>


                    <Grid item lg={4} xs={12} sx={{ borderLeft: "2px solid #09aff4", height: "200px", marginTop: { lg: "50px", xs: "0" }, paddingLeft: "10px" }}>
                        <Typography variant='h5' sx={{ fontWeight: "700", color: "white", marginTop: "40px", }}>Contact Us</Typography>
                        <Box sx={{ display: "flex", alignItems: "center", marginTop: "20px" }}>
                            <Typography component={"img"} src={msg} />
                            <Typography variant='p' sx={{ color: "white", fontWeight: "700", marginLeft: "10px", fontSize: { lg: "17px", xs: "18px" }, lineHeight: "25px", }}>99 Hudson Street Tribeca, Lower Manhattan, 5th Floor, New York City, NY, 10013, USA</Typography>
                        </Box>
                    </Grid>

                    <Grid item lg={4} xs={12} sx={{ borderLeft: "2px solid #09aff4", height: "200px", marginTop: { lg: "50px", xs: "0" }, paddingLeft: "10px" }}>
                        <Typography variant='h5' sx={{ fontWeight: "700", color: "white", marginTop: "40px", }}>Phone</Typography>
                        <Box sx={{ display: "flex", alignItems: "center", marginTop: "20px" }}>
                            <Typography component={"img"} src={phone} />
                            <Typography variant='p' sx={{ color: "white", fontWeight: "bold", fontSize: { lg: "15px", xs: "20px" } }}>(xxx)(xxx)(xxxx)</Typography>
                        </Box>
                    </Grid>

                </Grid>
            </Container>
        </Box>
    )
}

export default ContactSection2
