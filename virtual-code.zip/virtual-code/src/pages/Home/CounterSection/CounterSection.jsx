import { Box, Container, Grid } from '@mui/material'
import React, { useEffect, useState } from 'react'
import "./CounterSection.css"
import logo1 from "../../../assets/Group 4.svg"
const CounterSection = () => {
    const [counter1, setCounter1] = useState(0)
    const [counter2, setCounter2] = useState(0)
    const [counter3, setCounter3] = useState(0)
    const [counter4, setCounter4] = useState(0)


    useEffect(() => {
        const intervalId = setInterval(() => {
            if (counter1 < 750) {
                setCounter1(prevCounter => prevCounter + 1);
            } else {
                clearInterval(intervalId);
            }
        }, 1);

        return () => clearInterval(intervalId);
    }, [counter1]);

    useEffect(() => {
        const intervalId = setInterval(() => {
            if (counter2 < 23) {
                setCounter2(prevCounter => prevCounter + 1);
            } else {
                clearInterval(intervalId);
            }
        }, 100);

        return () => clearInterval(intervalId);
    }, [counter2]);


    useEffect(() => {
        const intervalId = setInterval(() => {
            if (counter3 < 200) {
                setCounter3(prevCounter => prevCounter + 1);
            } else {
                clearInterval(intervalId);
            }
        }, 10);

        return () => clearInterval(intervalId);
    }, [counter3]);

    useEffect(() => {
        const intervalId = setInterval(() => {
            if (counter4 < 28) {
                setCounter4(prevCounter => prevCounter + 1);
            } else {
                clearInterval(intervalId);
            }
        }, 120);

        return () => clearInterval(intervalId);
    }, [counter4]);


    return (
        <Box className="main2-bg" sx={{ color: "white", textAlign: "center", height: { lg: "0", sm: "55%", md: "55%" }, paddingY: { lg: "0", xs: "30px", sm: "30px" } }}>
            <Container maxWidth={"xl"}>
                <Grid container spacing={{ lg: 10, xs: 2 }} >
                    <Grid item lg={3} sm={6} xs={12}>
                        <Box sx={{ border: "2px solid #09aff4", width: "100%", height: { lg: "250px", md: "320px", xs: "220px" }, backgroundColor: "rgba(2, 0, 36, 0.2)", margin: "0 auto", lineHeight: "35px" }}>
                            <img src={logo1} style={{ marginTop: "20px" }} />
                            <h1>{counter1}+</h1>
                            <p>Finish Projects</p>
                        </Box>
                    </Grid>
                    <Grid item lg={3} sm={6} xs={12}>
                        <Box sx={{ border: "2px solid #09aff4", width: "100%", height: { lg: "250px", md: "320px", xs: "220px" }, backgroundColor: "rgba(2, 0, 36, 0.2)", margin: "0 auto" }}>
                            <img src={logo1} style={{ marginTop: "20px" }} />
                            <h1>{counter2}+</h1>
                            <p>Created Jobs</p>
                        </Box>
                    </Grid>
                    <Grid item lg={3} md={6} sm={6} xs={12}>
                        <Box sx={{ border: "2px solid #09aff4", width: "100%", height: { lg: "250px", md: "320px", xs: "220px" }, backgroundColor: "rgba(2, 0, 36, 0.2)", margin: "0 auto" }}>
                            <img src={logo1} style={{ marginTop: "20px" }} />
                            <h1>{counter3}+</h1>
                            <p>Happy Customers</p>
                        </Box>
                    </Grid>
                    <Grid item lg={3} sm={6} xs={12}>
                        <Box sx={{ border: "2px solid #09aff4", width: "100%", height: { lg: "250px", md: "320px", xs: "220px" }, backgroundColor: "rgba(2, 0, 36, 0.2)", margin: "0 auto" }}>
                            <img src={logo1} style={{ marginTop: "20px" }} />
                            <h1>{counter4}+</h1>
                            <p>Years Of Experience</p>
                        </Box>
                    </Grid>
                </Grid>

            </Container>
        </Box >
    )
}

export default CounterSection
