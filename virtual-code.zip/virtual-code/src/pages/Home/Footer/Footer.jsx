import { Box, Container, Divider, Grid, IconButton, Link, List, Typography } from '@mui/material'
import React from 'react'
import "./Footer.css"
import FacebookIcon from '@mui/icons-material/Facebook';
import YouTubeIcon from '@mui/icons-material/YouTube';
import InstagramIcon from '@mui/icons-material/Instagram';
import TwitterIcon from '@mui/icons-material/Twitter';

const Footer = () => {
    return (
        <Box className="main-bg">
            <Box sx={{ textAlign: "center", color: "white", marginTop: { lg: "80px", xs: "10px" }, paddingTop: "50px" }}>
                <Grid container sx={{ width: { lg: "67%", sm: "100%" }, marginX: "auto" }}>
                    <Grid item lg={12} sm={12} xs={12}> <Typography variant='h3' sx={{ fontWeight: "bold", fontSize: { lg: "48px", sm: "36px", xs: "26px" } }}>Subscribe to our Newsletter</Typography></Grid>
                    <Grid item lg={12} sm={12} xs={11} sx={{ marginX: "auto", lineHeight: "28px" }}>
                        <Typography variant='p' >We handpick the very best deals, trends and product news - making sure you never miss a thing.</Typography>
                    </Grid>
                    <Grid item lg={12} sx={{ marginX: "auto", paddingTop: "20px" }}>
                        <input
                            type="text"
                            placeholder='Email Address'
                            className="custom-input-subscribe"
                        />
                    </Grid>
                </Grid>

                <Container maxWidth={"xl"}>
                    <Grid container sx={{ borderTop: "2px solid rgb(255, 255, 255)", width: "80%", marginX: "auto", marginTop: "30px", textAlign: "start" }}>
                        <Grid item lg={8} xs={12}>
                            <Typography variant='h4' sx={{ paddingTop: "40px", fontWeight: "700", color: " rgb(252, 254, 254)" }}>Brand Logo</Typography>
                            <Box sx={{ width: "100%" }}>

                                <br />
                                <br />
                                <Typography variant='p' sx={{ paddingTop: "40px", fontSize: "18px" }}>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</Typography>
                                <br />
                                <br />
                                <br />
                                <br />
                                <Typography variant='p' sx={{ paddingTop: "40px", fontSize: "18px" }}>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</Typography>
                            </Box>

                        </Grid>
                        <Grid item lg={2} xs={6}>
                            <Typography variant='h6' sx={{ paddingTop: "40px", fontWeight: "400", }}>Lorem ipsum</Typography>
                            <ul>
                                <List sx={{ listStyle: "none" }}><Link sx={{ color: "white", textDecoration: "none" }}>Lorem ipsum</Link></List>
                                <List sx={{ listStyle: "none" }}><Link sx={{ color: "white", textDecoration: "none" }}>Lorem ipsum</Link></List>
                                <List sx={{ listStyle: "none" }}><Link sx={{ color: "white", textDecoration: "none" }}>Lorem ipsum</Link></List>
                                <List sx={{ listStyle: "none" }}><Link sx={{ color: "white", textDecoration: "none" }}>Lorem ipsum</Link></List>
                                <List sx={{ listStyle: "none" }}><Link sx={{ color: "white", textDecoration: "none" }}>Lorem ipsum</Link></List>
                                <List sx={{ listStyle: "none" }}><Link sx={{ color: "white", textDecoration: "none" }}>Lorem ipsum</Link></List>

                            </ul>
                        </Grid>
                        <Grid item lg={2} xs={6}>
                            <Typography variant='h6' sx={{ paddingTop: "40px", fontWeight: "400" }}>Partners & Advertisers</Typography>
                            <ul>
                                <List sx={{ listStyle: "none" }}><Link sx={{ color: "white", textDecoration: "none" }}>Why Brand?</Link></List>
                                <List sx={{ listStyle: "none" }}><Link sx={{ color: "white", textDecoration: "none" }}>Safe Shopping</Link></List>
                                <List sx={{ listStyle: "none" }}><Link sx={{ color: "white", textDecoration: "none" }}>Membership</Link></List>
                                <List sx={{ listStyle: "none" }}><Link sx={{ color: "white", textDecoration: "none" }}>FAQ’s</Link></List>
                                <List sx={{ listStyle: "none" }}><Link sx={{ color: "white", textDecoration: "none" }}>Privacy Settings</Link></List>


                            </ul>
                        </Grid>

                    </Grid>
                    <Grid container sx={{ borderTop: "2px solid rgb(255, 255, 255)", width: "80%", marginX: "auto", marginTop: "30px", }} justifyContent={{ lg: "end", sm: "space-between", xs: "center" }}>
                        <Grid item lg={6} sx={{ textAlign: "start", paddingTop: "20px" }}>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                        </Grid>
                        <Grid item sx={{ textAlign: "end" }} lg={6}>
                            <IconButton sx={{ color: "lightgray" }}><FacebookIcon sx={{ fontSize: "30px" }} /></IconButton>
                            <IconButton sx={{ color: "lightgray" }}><YouTubeIcon sx={{ fontSize: "30px" }} /></IconButton>
                            <IconButton sx={{ color: "lightgray" }}><InstagramIcon sx={{ fontSize: "30px" }} /></IconButton>
                            <IconButton sx={{ color: "lightgray" }}><TwitterIcon sx={{ fontSize: "30px" }} /></IconButton>
                        </Grid>
                    </Grid>
                </Container>
            </Box>
        </Box >
    )
}

export default Footer


