import { Box, Button, Container, Grid, IconButton, Typography } from '@mui/material'
import React from 'react'
import "./Header.css"
import Navbar from '../Navbar/Navber'
import FacebookIcon from '@mui/icons-material/Facebook';
import YouTubeIcon from '@mui/icons-material/YouTube';
import InstagramIcon from '@mui/icons-material/Instagram';
import TwitterIcon from '@mui/icons-material/Twitter';

import banner1 from "../../../assets/illustration-1 1.svg"

const Header = () => {

    return (
        <Box className="main-bg">
            <Navbar />
            <Container maxWidth={"xl"} sx={{ paddingBottom: "30px" }}>
                <Grid container justifyContent="center" alignItems="center">
                    <Grid item lg={6} sm={12} >
                        <Box sx={{ paddingLeft: { xs: "0", sm: "3.4%", lg: "3rem" }, paddingY: { xs: "1rem", lg: "9rem" }, width: { lg: "90%", xs: "100%" }, lineHeight: "25px" }}>
                            <IconButton sx={{ color: "lightgray" }}><FacebookIcon sx={{ fontSize: "30px" }} /></IconButton>
                            <IconButton sx={{ color: "lightgray" }}><YouTubeIcon sx={{ fontSize: "30px" }} /></IconButton>
                            <IconButton sx={{ color: "lightgray" }}><InstagramIcon sx={{ fontSize: "30px" }} /></IconButton>
                            <IconButton sx={{ color: "lightgray" }}><TwitterIcon sx={{ fontSize: "30px" }} /></IconButton>
                            <Typography variant='h5' sx={{ display: "flex", color: "#09aff4", fontWeight: "bold", fontSize: "20px" }}> <span style={{ fontSize: "22px", margin: "0 3px" }}>•</span>
                                Web Solution <span style={{ fontSize: "22px", margin: "0 3px" }}>•</span></Typography>

                            <Typography component={"p"} sx={{ fontWeight: "bold", color: "lightgray", fontSize: { lg: "48px", md: "40px", sm: "35px", xs: "30px", }, }}>
                                Providing The Best Services & Web <span className="solution">Solutions</span>
                            </Typography>
                            <Box sx={{ marginTop: "40px" }}>
                                <p style={{ color: "lightgray", width: { lg: "70%", xs: "100%" } }}>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed architecto dolorum inventore totam adipisci</p>
                                <Box sx={{ marginY: "10px", }}>
                                    <Button sx={{ border: "2px solid rgb(72, 172, 213)", color: "#09aff4", borderRadius: "0 10px", fontSize: "16px", fontWeight: "700", width: "fit-content", margin: "0 10px", height: "45px", marginLeft: "1px", "&:hover": { border: "2px solid white", color: "white" } }}>Our Services</Button>
                                    <Button sx={{ border: "2px solid rgb(72, 172, 213)", color: "#09aff4", borderRadius: "0 10px", fontSize: "16px", fontWeight: "700", width: "fit-content", margin: "0 20px", height: "45px", "&:hover": { border: "2px solid white", color: "white" } }}>Contact Us</Button>
                                </Box>
                            </Box>
                        </Box>
                    </Grid>
                    <Grid item lg={6} sm={12}>
                        <Box sx={{ paddingY: { lg: "40px", xs: "20px" } }}>

                            <Typography component={"img"} src={banner1} className='move-img' sx={{ width: { lg: "80%", xs: "90%" } }} />
                        </Box>
                    </Grid>
                </Grid>

            </Container>
        </Box >
    )
}

export default Header
