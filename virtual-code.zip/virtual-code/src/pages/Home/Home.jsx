import React from 'react'
import Header from './Header/Header'
import SectionCollection from './SectionCollection/SectionCollection'

const Home = () => {
    return (
        <div>    
            <Header />
            <SectionCollection />

        </div>
    )
}

export default Home
