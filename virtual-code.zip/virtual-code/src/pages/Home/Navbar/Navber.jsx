import { Box, Collapse, Fade, IconButton, Typography } from '@mui/material'
import React, { useState } from 'react'
import MenuIcon from '@mui/icons-material/Menu';
import About from '../../About/About';
import Home from '../Home';
import { Link, NavLink } from 'react-router-dom';
import "./Navbar.css"
const Navbar = () => {

  const [openList, setOpenList] = useState(false)

  return (
    // For Desktop & Tablet
    <>
      <Box sx={{ display: { lg: 'block', md: 'none', sm: 'none', xs: 'none' } }}>
        <Box sx={{ display: 'flex', justifyContent: 'center' }}>
          <Box
            sx={{
              color: 'white',
              marginTop: '40px',
              margin: { lg: '40px 200px', md: '40px 0', sm: '40px 0', xs: '40px 0' },
            }}
          >
            <NavLink to="/" style={{ textDecoration: 'none', color: 'inherit' }}>
              <h1>Brand Logo</h1>
            </NavLink>
          </Box>

          <Box>
            <Typography
              component="ul"
              sx={{
                display: 'flex',
                color: 'white',
                fontWeight: '600',
                textAlign: 'center',
                listStyle: 'none',
                marginRight: {
                  lg: '200px',
                  md: '0px',
                },
                marginTop: '40px',
                fontSize: '20px',
                justifyContent: 'space-between',
                'li:hover': { listStyle: 'disc', color: '#09aff4', transition: '0.3s' },

              }}
            >
              <li style={{ margin: '0 40px', listStyle: "disc", color: '#09aff4' }}>
                <NavLink to="/" style={{ textDecoration: 'none', color: '#09aff4', }}>Home</NavLink>
              </li>
              <li style={{ margin: '0 40px' }}>
                <NavLink to="/about" className={"active"}>About Us</NavLink>
              </li>
              <li style={{ margin: '0 40px' }}>
                <NavLink to="/services" className={"active"}>Services</NavLink>
              </li>
              <li style={{ margin: '0 40px' }}>
                <NavLink to="/portfolio" className={"active"}>Portfolio</NavLink>
              </li>
              <li style={{ margin: '0 40px' }}>
                <NavLink to="/packages" className={"active"}>Packages</NavLink>
              </li>
              <li style={{ margin: '0 40px' }}>
                <NavLink to="/contact" className={"active"}>Contact Us</NavLink>
              </li>
            </Typography>
          </Box>
        </Box>
      </Box>

      {/* For Mobile &  */}

      <Box sx={{ display: { lg: "none", md: "block", sm: "block", xs: "block" } }}>
        <Box sx={{ display: "flex", justifyContent: "space-evenly" }}>
          <Box sx={{ color: "white", marginTop: "40px", marginRight: { lg: "200px", xs: "150px" }, fontSize: { lg: "36px", xs: "12px", sm: "16px", md: "20px" } }}>
            <h1>Brand Logo</h1>
          </Box>
          <IconButton sx={{ color: "white", marginTop: { lg: "40px", xs: "20px" } }} onClick={() => setOpenList(!openList)} >
            <MenuIcon sx={{ fontSize: "30px" }} />
          </IconButton>
        </Box>

        <Box>
          {openList && (
            <Fade in={openList} timeout={800}>
              <Box>
                <Typography component={"ul"} sx={{ textAlign: "center", fontWeight: "bold", listStyle: "none", "li:hover": { color: "#09aff4", transition: "0.3s" }, "a:hover": { color: "#09aff4", } }}>
                  <li style={{ margin: '0 40px' }}>
                    <NavLink to="/" style={{ textDecoration: 'none', color: '#09aff4', }}>Home</NavLink>
                  </li>
                  <li style={{ margin: '0 40px' }}>
                    <NavLink to="/about" className={"active"}>About Us</NavLink>
                  </li>
                  <li style={{ margin: '0 40px' }}>
                    <NavLink to="/services" className={"active"}>Services</NavLink>
                  </li>
                  <li style={{ margin: '0 40px' }}>
                    <NavLink to="/portfolio" className={"active"}>Portfolio</NavLink>
                  </li>
                  <li style={{ margin: '0 40px' }}>
                    <NavLink to="/packages" className={"active"}>Packages</NavLink>
                  </li>
                  <li style={{ margin: '0 40px' }}>
                    <NavLink to="/contact" className={"active"}>Contact Us</NavLink>
                  </li>
                </Typography>
              </Box>
            </Fade>
          )}
        </Box>

      </Box >


    </>
  )
}

export default Navbar
