import React from 'react';
import { Typography } from '@mui/material';

const ECommerceSection = () => {
    return (
        <Typography variant='h4'>E-Commerce Section</Typography>
    );
};

export default ECommerceSection;
