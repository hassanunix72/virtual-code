import { Box, Container, Grid, Link, Typography } from '@mui/material'
import React from 'react'
import portfolioSection from "../../../assets/Rectangle 16.svg"

const LogoSection = () => {
    return (
        <Container maxWidth={"xl"}>
            {/* 1st Row */}
            <Grid container sx={{ marginTop: "20px", }} spacing={6}>
                <Grid item lg={3} md={6} xs={12}>
                    <Box sx={{ border: "3px solid rgb(13, 202, 240)", borderRadius: { lg: "26px", md: "32px", sm: "50px", xs: "26px" }, width: "100%" }}>
                        <Link href="/"><Typography component={"img"} sx={{ width: "fit-content", verticalAlign: "middle" }} src={portfolioSection}></Typography></Link>
                    </Box>
                </Grid>
                <Grid item lg={3} md={6} xs={12}>
                    <Box sx={{ border: "3px solid rgb(13, 202, 240)", borderRadius: { lg: "26px", md: "32px", sm: "50px", xs: "26px" }, width: "100%" }}>
                        <Link href="/"><Typography component={"img"} sx={{ width: "100%", verticalAlign: "middle" }} src={portfolioSection}></Typography></Link>
                    </Box>
                </Grid>
                <Grid item lg={3} md={6} xs={12}>
                    <Box sx={{ border: "3px solid rgb(13, 202, 240)", borderRadius: { lg: "26px", md: "32px", sm: "50px", xs: "26px" }, width: "100%" }}>
                        <Link href="/"><Typography component={"img"} sx={{ width: "100%", verticalAlign: "middle" }} src={portfolioSection}></Typography></Link>
                    </Box>
                </Grid>
                <Grid item lg={3} md={6} xs={12}>
                    <Box sx={{ border: "3px solid rgb(13, 202, 240)", borderRadius: { lg: "26px", md: "32px", sm: "50px", xs: "26px" }, width: "100%" }}>
                        <Link href="/"><Typography component={"img"} sx={{ width: "100%", verticalAlign: "middle" }} src={portfolioSection}></Typography></Link>
                    </Box>
                </Grid>
            </Grid>


            {/* 2nd Row */}

            <Grid container sx={{ marginTop: "1px", }} spacing={6}>
                <Grid item lg={3} md={6} xs={12}>
                    <Box sx={{ border: "3px solid rgb(13, 202, 240)", borderRadius: { lg: "26px", md: "32px", sm: "50px", xs: "26px" }, width: "100%" }}>
                        <Link href="/"><Typography component={"img"} sx={{ width: "100%", verticalAlign: "middle" }} src={portfolioSection}></Typography></Link>
                    </Box>
                </Grid>
                <Grid item lg={3} md={6} xs={12}>
                    <Box sx={{ border: "3px solid rgb(13, 202, 240)", borderRadius: { lg: "26px", md: "32px", sm: "50px", xs: "26px" }, width: "100%" }}>
                        <Link href="/"><Typography component={"img"} sx={{ width: "100%", verticalAlign: "middle" }} src={portfolioSection}></Typography></Link>
                    </Box>
                </Grid>
                <Grid item lg={3} md={6} xs={12}>
                    <Box sx={{ border: "3px solid rgb(13, 202, 240)", borderRadius: { lg: "26px", md: "32px", sm: "50px", xs: "26px" }, width: "100%" }}>
                        <Link href="/"><Typography component={"img"} sx={{ width: "100%", verticalAlign: "middle" }} src={portfolioSection}></Typography></Link>
                    </Box>
                </Grid>
                <Grid item lg={3} md={6} xs={12}>
                    <Box sx={{ border: "3px solid rgb(13, 202, 240)", borderRadius: { lg: "26px", md: "32px", sm: "50px", xs: "26px" }, width: "100%" }}>
                        <Link href="/"><Typography component={"img"} sx={{ width: "100%", verticalAlign: "middle" }} src={portfolioSection}></Typography></Link>
                    </Box>
                </Grid>
            </Grid>
        </Container >   
    )
}

export default LogoSection
