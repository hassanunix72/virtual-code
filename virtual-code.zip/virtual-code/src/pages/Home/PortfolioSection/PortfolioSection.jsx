import { Box, Button, Collapse, Container, Fade, Grid, Typography } from '@mui/material'
import React, { useState } from 'react'
import LogoSection from "./LogoSection"
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import ECommerceSection from './ECommerceSection';
import WebDesignSection from './WebDesignSection';
const PortfolioSection = () => {

    const [nav, setNav] = useState('logo')


    const renderSection = () => {

        switch (nav) {
            case 'logo':
                return <LogoSection />;
            case 'webDesign':
                return <WebDesignSection />;
            case 'eCommerce':
                return <ECommerceSection />;
            default:
                return null;
        }
    };

    return (

        <Box sx={{ backgroundColor: "#181757", textAlign: "center", color: "white", }}>
            <Container maxWidth={"xl"} >
                <Grid container justifyContent="center" >
                    <Grid item lg={6} sx={{ marginTop: "50px" }}>

                        <Typography variant='h6' sx={{ color: "#09aff4", fontWeight: "bold", display: "flex", justifyContent: "center", alignItems: "center" }}>
                            <span style={{ fontSize: "25px", marginRight: "4px" }}>•</span>
                            Our Services
                            <span style={{ fontSize: "25px", marginLeft: "4px" }}>•</span>
                        </Typography>

                        <Typography variant='h3' sx={{ fontWeight: "700", margin: "10px 0", fontSize: { lg: "48px", md: "40px", xs: "30px" } }}>Awesome Portfolio</Typography>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sedarchitecto dolorum inventore totam adipisci</p>
                    </Grid>


                    <Grid item lg={1} xs={6} sx={{ marginTop: { lg: "100px", xs: "20px" }, paddingLeft: { lg: "60px", }, marginRight: { xs: "20px" } }}>
                        <Button sx={{ border: "2px solid rgb(72, 172, 213)", color: "#09aff4", borderRadius: "0 10px", fontSize: "16px", fontWeight: "700", width: { lg: "180px", xs: "90%", sm: "100%", }, display: "flex", margin: "10px 20px", height: "45px", "&:hover": { border: "2px solid white", color: "white" } }}>See More <ArrowForwardIcon sx={{ marginBottom: "4px" }} /></Button>
                    </Grid>
                </Grid>

                {/* Portfolio Button*/}
                <Container sx={{ marginTop: "20px", }} >
                    <Grid container spacing={{ xs: 3, lg: 2 }} sx={{ marginRight: "20px" }}>
                        <Grid item lg={2} xs={6}>
                            <Box >  <Button onClick={() => setNav('logo')} sx={{ border: "3px solid rgb(72, 172, 213)", color: "#09aff4", borderRadius: "0 10px", textTransform: "capitalize", fontSize: { lg: "18px", md: "22px", sm: "20px", xs: "16px" }, fontWeight: "700", width: "100%", textSizeAdjust: "100%", height: "45px", "&:hover": { border: "2px solid white", color: "white" } }}>Logo Design </Button></Box>
                        </Grid>
                        <Grid item lg={2} xs={6}>
                            <Button onClick={() => setNav('webDesign')} sx={{ border: "3px solid rgb(72, 172, 213)", color: "#09aff4", borderRadius: "0 10px", textTransform: "capitalize", fontSize: { lg: "18px", md: "22px", sm: "20px", xs: "16px" }, fontWeight: "700", width: "100%", textSizeAdjust: "100%", height: "45px", "&:hover": { border: "2px solid white", color: "white" } }}>Web Design </Button>
                        </Grid>
                        <Grid item lg={2} xs={6}>
                            <Button onClick={() => setNav('eCommerce')} sx={{ border: "3px solid rgb(72, 172, 213)", color: "#09aff4", borderRadius: "0 10px", textTransform: "capitalize", fontSize: { lg: "18px", md: "22px", sm: "20px", xs: "16px" }, fontWeight: "700", width: "100%", textSizeAdjust: "100%", height: "45px", "&:hover": { border: "2px solid white", color: "white" } }}>E-Commerce </Button>
                        </Grid>
                        <Grid item lg={2} xs={6}>
                            <Button onClick={() => setNav('webDesign')} sx={{ border: "3px solid rgb(72, 172, 213)", color: "#09aff4", borderRadius: "0 10px", textTransform: "capitalize", fontSize: { lg: "18px", md: "22px", sm: "20px", xs: "16px" }, fontWeight: "700", width: "100%", textSizeAdjust: "100%", height: "45px", "&:hover": { border: "2px solid white", color: "white" } }}>Wordpress </Button>
                        </Grid>
                        <Grid item lg={2} xs={6}>
                            <Button onClick={() => setNav('logo')} sx={{ border: "3px solid rgb(72, 172, 213)", color: "#09aff4", borderRadius: "0 10px", textTransform: "capitalize", fontSize: { lg: "18px", md: "22px", sm: "20px", xs: "16px" }, fontWeight: "700", width: "100%", textSizeAdjust: "100%", height: "45px", "&:hover": { border: "2px solid white", color: "white" } }}>Motion Graphics </Button>
                        </Grid>
                        <Grid item lg={2} xs={6}>
                            <Button onClick={() => setNav('eCommerce')} sx={{ border: "3px solid rgb(72, 172, 213)", color: "#09aff4", borderRadius: "0 10px", textTransform: "capitalize", fontSize: { lg: "18px", md: "22px", sm: "20px", xs: "16px" }, fontWeight: "700", width: "100%", textSizeAdjust: "100%", height: "45px", "&:hover": { border: "2px solid white", color: "white" } }}>Shopify </Button>
                        </Grid>
                    </Grid>
                </Container>
                {/* Navigation Section */}
                <Fade key={nav} in={Boolean(nav)} timeout={500}>
                    <Box>
                        {renderSection()}
                    </Box>
                </Fade>
            </Container>

        </Box>
    )
}

export default PortfolioSection
