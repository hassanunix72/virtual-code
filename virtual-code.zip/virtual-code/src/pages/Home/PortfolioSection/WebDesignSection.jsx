import React from 'react';
import { Typography } from '@mui/material';

const WebDesignSection = () => {
    return (
        <Typography variant='h4'>Web Design Section</Typography>
    );
};

export default WebDesignSection;
