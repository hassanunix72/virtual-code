import { Box, Button, Container } from '@mui/material'
import React from 'react'
import "./PriceSection.css"
import CustomPlanLogo from '../../../components/CustomLogo/CustomPlanLogo'
const PriceCard = ({ headingLabel }) => {
    return (

        <Box className="custom_card_01" sx={{
            border: "2px solid #09aff4",
            height: { xs: "auto", md: "580px", lg: "520px" },
            width: { xs: "100%", sm: "calc(100% - 20px)", md: "calc(100% - 40px)", lg: "300px" },
            textAlign: "center",
            borderRadius: "8px",
            marginY: "40px",
            paddingTop: "20px",
            marginX: "auto",

        }}>
            <Container sx={{
                lineHeight: "40px",
                "& p:hover": {
                    color: "white"
                }
            }}>
                {/* <img src={img} style={{ margin: "20px 0", width: "30%", height: "auto", }} alt="Plan" /> */}
                <CustomPlanLogo />
                <h2 style={{ margin: "20px 0" }}>{headingLabel}</h2>
                <h1><sup style={{ fontSize: "15px" }}>$</sup>00</h1>
                <Container>
                    <ul>
                        <li>150 Lorem, ipsum.</li>
                        <li>200 Lorem, ipsum dolor.</li>
                        <li>80 Lorem, ipsum.</li>
                        <li>Free Lorem ipsum dolor sit.</li>
                        <li>Lorem ipsum dolor sit.</li>

                    </ul>

                </Container>
                <Box sx={{ marginBottom: "20px" }}>   <Button sx={{ border: "2px solid rgb(72, 172, 213)", color: "#09aff4", borderRadius: "0 10px", fontSize: "13px", fontWeight: "700", width: "150px", height: "45px", "&:hover": { border: "2px solid white", color: "white" } }}>Select Plan</Button></Box>
            </Container>
        </Box>
    )
}

export default PriceCard
