import { Box, Button, Container, Grid, Typography } from '@mui/material'
import React from 'react'
import PriceCard from './PriceCard'
import freeplan from "../../../assets/freeplan.svg"
import "./PriceSection.css"
const PriceSection = () => {
    return (
        <>
            <Container sx={{ textAlign: "center", color: "white" }}>
                <Grid container justifyContent="center" >
                    <Grid item lg={6} sx={{ marginTop: "50px" }}>

                        <Typography variant='h6' sx={{ color: "#09aff4", fontWeight: "bold", display: "flex", justifyContent: "center", alignItems: "center" }}>
                            <span style={{ fontSize: "25px", marginRight: "4px" }}>•</span>
                            PRICING PLANS
                            <span style={{ fontSize: "25px", marginLeft: "4px" }}>•</span>
                        </Typography>


                        <Typography variant='h3' sx={{ fontWeight: "700", margin: "10px 0", fontSize: { lg: "48px", xs: "30px", sm: "36px" } }}>Affordable Pricing Plans</Typography>

                    </Grid>
                    <Grid item lg={12} xs={12}>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sedarchitecto dolorum inventore totam adipisci</p>
                    </Grid>
                </Grid>
                {/* Price Card Section */}
                <Grid container spacing={{ lg: 12, xs: 0 }} >
                    <Grid item lg={3} xs={12} sm={6} className='plan-logo'><PriceCard img={freeplan} headingLabel={"Free Plan"} /></Grid>
                    <Grid item lg={3} xs={12} sm={6} className='plan-logo'> <PriceCard img={freeplan} headingLabel={"Standard Plan"} /></Grid>
                    <Grid item lg={3} xs={12} sm={6} className='plan-logo'> <PriceCard img={freeplan} headingLabel={"Pro Plan"} /></Grid>
                    <Grid item lg={3} xs={12} sm={6} className='plan-logo'> <PriceCard img={freeplan} headingLabel={"Ultimate Plan"} /></Grid>
                </Grid>
            </Container>


        </>
    )
}

export default PriceSection
