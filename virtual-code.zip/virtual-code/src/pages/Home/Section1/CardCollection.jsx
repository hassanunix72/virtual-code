import React from 'react'
import SectionCard from './SectionCard'
import { Box, Container, Grid } from '@mui/material'
import "../PriceSection/PriceSection.css"
import web from "../../../assets/Group.svg"
import digital from "../../../assets/Group2.svg"
import idea from "../../../assets/Group3.svg"

const CardCollection = () => {
    return (
        <Box sx={{ marginX: "auto" }}>
            <Grid container >
                <Grid item lg={3} xs={12} sx={{ margin: { lg: "10px 30px", xs: "10px 0" } }} className='plan-logo'>
                    <SectionCard headingLabel={"Web Development"} img={web} />
                </Grid>
                <Grid item lg={3} xs={12} sx={{ margin: { lg: "10px 30px", xs: "10px 0" } }}>
                    <SectionCard headingLabel={"Web Development"} img={digital} />
                </Grid>
                <Grid item lg={3} xs={12} sx={{ margin: { lg: "10px 30px", xs: "10px 0" } }}>
                    <SectionCard headingLabel={"Web Development"} img={idea} />
                </Grid>
                <Grid item lg={3} xs={12} sx={{ margin: { lg: "10px 30px", xs: "10px 0" } }}>
                    <SectionCard headingLabel={"Web Development"} img={web} />
                </Grid>
                <Grid item lg={3} xs={12} sx={{ margin: { lg: "10px 30px", xs: "10px 0" } }}>
                    <SectionCard headingLabel={"Web Development"} img={digital} />
                </Grid>
                <Grid item lg={4} xs={12} sx={{ margin: { lg: "10px 30px", xs: "10px 0" } }}>
                    <SectionCard headingLabel={"Web Development"} img={digital} />
                </Grid>
            </Grid>
        </Box>
    )
}

export default CardCollection
