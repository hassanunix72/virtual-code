import { Box, Button, Container, Grid, Typography } from '@mui/material'
import React from 'react'
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import CardCollection from './CardCollection';
import Section2 from './Section2';

const Section1 = () => {
    return (
        <>
            <Box sx={{ backgroundColor: "#181757", textAlign: "center", color: "white", minHeight: "100vh", maxHeight: "100%", paddingTop: "40px" }}>
                <Container maxWidth={"xl"} >
                    <Grid container justifyContent="center" >
                        <Grid item lg={6} >

                            <Typography variant='h6' sx={{ color: "#09aff4", fontWeight: "bold", display: "flex", justifyContent: "center", alignItems: "center" }}>
                                <span style={{ fontSize: "25px", marginRight: "4px" }}>•</span>
                                Our Services
                                <span style={{ fontSize: "25px", marginLeft: "4px" }}>•</span>
                            </Typography>


                            <Typography variant='h3' sx={{ fontWeight: "700", margin: "10px 0", fontSize: { lg: "48px", sm: "30px", xs: "25px", md: "48px" } }}>Services We Offer

                            </Typography>
                            <Typography sx={{ fontSize: { lg: "15px", xs: "15px" }, textAlign: "center" }}>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sedarchitecto dolorum inventore totam adipisci</Typography>
                        </Grid>


                        <Grid item lg={1} xs={6} sx={{ marginTop: { lg: "60px", xs: "30px" }, paddingLeft: { lg: "130px", xs: "0" } }}>
                            <Button sx={{ border: "2px solid rgb(72, 172, 213)", color: "#09aff4", borderRadius: "0 10px", fontSize: { lg: "18px", xs: "16px", md: "30px", sm: "25px" }, fontWeight: "bold", width: { lg: "200px", xs: "100%", sm: "100%" }, margin: { lg: "0 20px", xs: "0" }, height: { lg: "50px", sm: "60px", xs: "50px" }, "&:hover": { border: "2px solid white", color: "white" } }}>Our Services <ArrowForwardIcon sx={{ marginBottom: "4px" }} /></Button>
                        </Grid>
                    </Grid>
                    {/* Section Cards */}
                    <Box sx={{ marginTop: "50px" }}>
                        <CardCollection />
                    </Box>

                </Container>
                {/* 2nd Section Start */}
                <Box marginTop={"50px"} >
                    <Section2 />
                </Box>

                {/* 2nd Section End */}
            </Box>


        </>

    )
}

export default Section1
