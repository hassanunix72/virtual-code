import { Box, Button, Grid, Typography } from '@mui/material'
import React from 'react'
import banner3 from "../../../assets/banner3.svg"
import logo1 from "../../../assets/Group 4.svg"
import logo2 from "../../../assets/Group 5.svg"
import logo3 from "../../../assets/Group 6.svg"
import logo4 from "../../../assets/Group 7.svg"
import logo5 from "../../../assets/Group 8.svg"
import logo6 from "../../../assets/Group 9.svg"


const Section2 = () => {
    return (
        <>
            <Box sx={{ width: { lg: "65%", sm: "70%", xs: "100%" }, margin: "0 auto", height: "100%" }}>
                <Grid container justifyContent="center" >
                    <Grid item lg={6} >

                        <Typography variant='h6' sx={{ color: "#09aff4", fontWeight: "bold", display: "flex", justifyContent: "center", alignItems: "center" }}>
                            <span style={{ fontSize: "25px", marginRight: "4px" }}>•</span>
                            Our Services
                            <span style={{ fontSize: "25px", marginLeft: "4px" }}>•</span>
                        </Typography>


                        <Typography variant='h3' sx={{ fontWeight: "700", margin: "10px 0", fontSize: { lg: "48px", sm: "30px", xs: "25px" } }}>Why Our Customer <br /> Choose <span style={{ color: "#09aff4" }}>Working</span> With Us</Typography>
                        <Typography sx={{ fontSize: { lg: "15px", xs: "15px" }, textAlign: "center" }}>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sedarchitecto dolorum inventore totam adipisci</Typography>
                    </Grid>


                    <Grid item lg={1} xs={6} sx={{ marginTop: { lg: "100px", xs: "30px" }, paddingLeft: { lg: "130px", xs: "0" } }}>
                        <Button sx={{ border: "2px solid rgb(72, 172, 213)", color: "#09aff4", borderRadius: "0 10px", fontSize: "15px", fontWeight: "bold", width: "150px", margin: "0 20px", height: "50px", "&:hover": { border: "2px solid white", color: "white" } }}>Get In Touch</Button>
                    </Grid>
                </Grid>
                {/* Hero Section */}
                <Grid container justifyContent={"space-evenly"} alignItems={"center"} sx={{ marginTop: { lg: "60px", xs: "20px" } }}>

                    <Grid item lg={4} xs={12} sx={{ textAlign: "start" }}>

                        <Box sx={{ display: "flex", }}>
                            <img src={logo1} />
                            <Box sx={{ margin: "10px" }}>
                                <h2>Pricing</h2>
                                <p style={{ margin: "10px 0", lineHeight: "25px" }}>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sedarchitecto dolorum inventore totam adipisci</p>
                            </Box>
                        </Box>
                        <Box sx={{ display: "flex", }}>
                            <img src={logo2} />
                            <Box sx={{ margin: "10px" }}>
                                <h2>Approach</h2>
                                <p style={{ margin: "10px 0", lineHeight: "25px" }}>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sedarchitecto dolorum inventore totam adipisci</p>
                            </Box>
                        </Box>
                        <Box sx={{ display: "flex", }}>
                            <img src={logo3} />
                            <Box sx={{ margin: "10px" }}>
                                <h2>Products</h2>
                                <p style={{ margin: "10px 0", lineHeight: "25px" }}>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sedarchitecto dolorum inventore totam adipisci</p>
                            </Box>
                        </Box>
                    </Grid>

                    <Grid item lg={2} xs={12}>
                        <Typography component={"img"} src={banner3} sx={{ width: { lg: "400px", xs: "250px" } }}></Typography>
                    </Grid>

                    <Grid item lg={4} xs={12} sx={{ textAlign: "start", marginLeft: { lg: "200px" } }}>
                        <Box sx={{ display: "flex", }}>
                            <img src={logo4} />
                            <Box sx={{ margin: "10px" }}>
                                <h2>Experience</h2>
                                <p style={{ margin: "10px 0", lineHeight: "25px" }}>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sedarchitecto dolorum inventore totam adipisci</p>
                            </Box>
                        </Box>
                        <Box sx={{ display: "flex", }}>
                            <img src={logo5} />
                            <Box sx={{ margin: "10px" }}>
                                <h2>Delivery</h2>
                                <p style={{ margin: "10px 0", lineHeight: "25px" }}>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sedarchitecto dolorum inventore totam adipisci</p>
                            </Box>
                        </Box>
                        <Box sx={{ display: "flex", }}>
                            <img src={logo6} />
                            <Box sx={{ margin: "10px" }}>
                                <h2>Support</h2>
                                <p style={{ margin: "10px 0", lineHeight: "25px" }}>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sedarchitecto dolorum inventore totam adipisci</p>
                            </Box>
                        </Box>
                    </Grid>
                </Grid>
            </Box>
        </>
    )
}

export default Section2
