import { Box, Container, Grid } from '@mui/material'
import React from 'react'
import "./Section.css"
const SectionCard = ({ headingLabel, img }) => {
    return (
        <Container >


            <Box className="custom_card_01" sx={{
                border: "2px solid #09aff4",
                height: { lg: "300px", xs: "90%" },
                width: { lg: "400px",},
                textAlign: "start",
                borderRadius: "5px",


            }}>
                <Container sx={{
                    "p:hover": {
                        color: "white"
                    }
                }}>
                    <img src={img} style={{ margin: "20px 0", color: "white" }} width={"55px"} />
                    <h3 style={{ margin: "20px 0" }}>
                        {headingLabel}
                    </h3>
                    <p style={{ margin: "20px 0", width: "90%", lineHeight: "25px" }}>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sedarchitecto dolorum inventore totam adipisci</p>

                    <p style={{ color: "#09aff4", margin: "20px 0", }}>Read More</p>
                </Container>
            </Box>

        </Container>
    )
}

export default SectionCard
