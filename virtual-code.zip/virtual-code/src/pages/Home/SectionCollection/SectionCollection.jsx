import React from 'react'
import Section1 from '../Section1/Section1'
import CounterSection from '../CounterSection/CounterSection'
import { Box } from '@mui/material'
import PortfolioSection from '../PortfolioSection/PortfolioSection'
import SocialSection from '../SocialSection/SocialSection'
import PriceSection from '../PriceSection/PriceSection'
import Slider from '../TestimonialSection/Slider'
import ContactSection from '../ContactSection/ContactSection'
import ContactSection2 from '../ContactSection/ContactSection2'
import Footer from '../Footer/Footer'

const SectionCollection = () => {
    return (
        <Box sx={{ backgroundColor: "#181757" }}>
            <Box >
                <Section1 />
            </Box>
            <Box sx={{ marginTop: "150px" }}>
                <CounterSection />
            </Box>
            <Box >
                <PortfolioSection />
            </Box>
            <Box sx={{ marginTop: "120px" }}>
                <SocialSection />
            </Box>
            <Box>
                <PriceSection />
            </Box>
            <Box>
                <Slider />
            </Box>
            <Box>
                <ContactSection />
            </Box>
            <Box>
                <Footer />
            </Box>

        </Box>
    )
}

export default SectionCollection
