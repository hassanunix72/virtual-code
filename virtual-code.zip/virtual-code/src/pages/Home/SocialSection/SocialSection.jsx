import { Box, Container, Grid, IconButton, Link, Typography } from '@mui/material'
import React from 'react'
import "./SocialSection.css"

import Instagram from "../../../assets/instagram.svg"
import whatsapp from "../../../assets/whatsapp.svg"
import facebook from "../../../assets/facebook.svg"
import discord from "../../../assets/discord.svg"
import chatGpt from "../../../assets/chatGpt.svg"
const SocialSection = () => {
    return (
        <Box className="main2-bg" sx={{ minHeight: "40vh", display: "flex", flexDirection: "column", justifyContent: "center" }}>
            <Container maxWidth={"xl"} sx={{ textAlign: "center", paddingY: "20px" }}>
                <Typography variant='h5' sx={{ fontWeight: "700", fontSize: "28px", color: "white" }}>Trusted By Over 500 Clients Around The World</Typography>
                <Grid container justifyContent="center" spacing={2} sx={{ marginTop: "20px" }}>
                    <Grid item lg={2} xs={12}>
                        <Box><IconButton sx={{ color: "white" }}><Link><Typography component={"img"} src={Instagram} sx={{ width: "100px" }} /></Link></IconButton></Box>
                    </Grid>
                    <Grid item lg={2} xs={12}>
                        <Box><IconButton sx={{ color: "white" }}><Link><Typography component={"img"} src={discord} sx={{ width: "100px" }} /></Link></IconButton></Box>
                    </Grid>
                    <Grid item lg={2} xs={12}>
                        <Box><IconButton sx={{ color: "white" }}><Link><Typography component={"img"} src={whatsapp} sx={{ width: "100px" }} /></Link></IconButton></Box>
                    </Grid>
                    <Grid item lg={2} xs={12}>
                        <Box><IconButton sx={{ color: "white" }}><Link><Typography component={"img"} src={facebook} sx={{ width: "100px" }} /></Link></IconButton></Box>
                    </Grid>
                    <Grid item lg={2} xs={12}>
                        <Box><IconButton sx={{ color: "white" }}><Link><Typography component={"img"} src={chatGpt} sx={{ width: "100px" }} /></Link></IconButton></Box>
                    </Grid>
                </Grid>
            </Container>
        </Box>
    )
}

export default SocialSection
