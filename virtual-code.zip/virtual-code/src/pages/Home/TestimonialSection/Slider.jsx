import React, { useState, useEffect } from "react";
import feedback from "../../../assets/feedback.svg"
import "./Slider.css";
// import { data } from "./data"
import { Box, IconButton, Typography } from "@mui/material";
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
const data = [
    {
        id: 1,
        image: feedback,
        name: "John Doe",
        title: "Software Engineer",
        quote: "Coding is my passion."
    },
    {
        id: 2,
        image: feedback,
        name: "Jane Smith",
        title: "Graphic Designer",
        quote: "Designing beautiful things every day."
    },
    {
        id: 3,
        image: feedback,
        name: "Michael Johnson",
        title: "Data Scientist",
        quote: "Turning data into insights."
    }
    // Add more objects as needed
];
const Slider = () => {
    const [people] = useState(data);
    const [index, setIndex] = useState(0);

    useEffect(() => {
        const lastIndex = people.length - 1;
        if (index < 0) {
            setIndex(lastIndex);
        }
        if (index > lastIndex) {
            setIndex(0);
        }
    }, [index, people]);

    useEffect(() => {
        let slider = setInterval(() => {
            setIndex(index + 1);
        }, 5000);
        return () => {
            clearInterval(slider);
        };
    }, [index]);

    return (
        <section className="section">
            <div className="title">

                <Typography variant='h6' sx={{ color: "#09aff4", fontWeight: "bold", display: "flex", justifyContent: "center", alignItems: "center" }}>
                    <span style={{ fontSize: "25px", marginRight: "4px" }}>•</span>
                    TESTIMONIALS
                    <span style={{ fontSize: "25px", marginLeft: "4px" }}>•</span>
                </Typography>

                <Typography variant="h3" sx={{ fontWeight: "700", color: "white", fontSize: { lg: "48px", xs: "32px", sm: "36px" } }}>Customer Testimonials</Typography>
            </div>
            <div className="section-center">
                {people.map((item, indexPeople) => {
                    const { id, image, name, title, quote } = item;
                    let position = "nextSlide";
                    if (indexPeople === index) {
                        position = "activeSlide";
                    }
                    if (
                        indexPeople === index - 1 ||
                        (index === 0 && indexPeople === people.length - 1)
                    ) {
                        position = "lastSlide";
                    }
                    return (
                        <article className={position} key={id}>
                            <img src={image} alt={name} className="person-img" />
                            <p className="text" style={{ color: "white" }}>{quote}</p>
                            <h4>{name}</h4>
                            <p style={{ color: "white" }}>{title}</p>

                        </article>
                    );
                })}
                <IconButton
                    className="prev"
                    onClick={() => setIndex(index - 1)}
                    sx={{
                        border: "2px solid #09aff4",
                        outline: "rgb(232, 230, 227) none 0px",
                        textAlign: "center",
                        width: "55px",
                        height: "55px",
                        display: { lg: "block", md: "block", sm: "none", xs: "none" },
                        "&:hover": {
                            transition: "border 0.30s",
                            border: "1px solid #09aff4",
                            color: "#09aff4"
                        }
                    }}
                >
                    <ArrowBackIosIcon
                        color="primary"
                        sx={{
                            marginY: "3.5px",
                            marginX: "8px",
                            fontSize: "30px",
                            "&:hover": {
                                transition: "0.5s",
                                color: "#09aff4"
                            }
                        }}
                    />
                </IconButton>

                <IconButton
                    className="next"
                    onClick={() => setIndex(index + 1)}
                    sx={{
                        border: "2px solid #09aff4",
                        textAlign: "center",
                        width: "55px",
                        height: "55px",
                        display: { lg: "block", md: "block", sm: "none", xs: "none" },
                        "&:hover": {
                            transition: "border 0.30s",
                            border: "1px solid #09aff4",
                            color: "#09aff4"
                        }
                    }}
                >
                    <ArrowForwardIosIcon
                        color="primary"
                        sx={{
                            marginY: "3px",
                            marginX: "5px",
                            fontSize: "30px",
                            "&:hover": {
                                transition: "0.5s",
                                color: "#09aff4"
                            }
                        }}
                    />
                </IconButton>

            </div>
        </section>
    );
};

export default Slider;
