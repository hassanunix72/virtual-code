


export const data = [
    {
        id: 1,
        image: {feedback},
        name: "John Doe",
        title: "Software Engineer",
        quote: "Coding is my passion."
    },
    {
        id: 2,
        image: "../../assets/feedback.svg",
        name: "Jane Smith",
        title: "Graphic Designer",
        quote: "Designing beautiful things every day."
    },
    {
        id: 3,
        image: "image3.jpg",
        name: "Michael Johnson",
        title: "Data Scientist",
        quote: "Turning data into insights."
    }
    // Add more objects as needed
];
