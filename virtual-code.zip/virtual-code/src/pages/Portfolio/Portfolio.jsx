import { Box, Typography } from '@mui/material'
import React from 'react'
import Navbar from '../Home/Navbar/Navber'
import AddHomeOutlinedIcon from '@mui/icons-material/AddHomeOutlined';
import Slider from '../Home/TestimonialSection/Slider';
import "./Portfolio.css"
import SocialSection from '../Home/SocialSection/SocialSection';
import ContactSection from '../Home/ContactSection/ContactSection';
import Footer from '../Home/Footer/Footer';
import PortfolioNavigation from './PortfolioNavigation';
const Portfolio = () => {
    return (
        <Box sx={{ bgcolor: "#181757" }} >
            <Box className="main3-bg" sx={{ height: { lg: "65vh", xs: "80%", md: "40vh" }, paddingBottom: "20px" }}>
                <Box><Navbar /></Box>
                <Box sx={{ textAlign: "center", marginY: "160px" }}>

                    <Typography variant='h3' sx={{ fontWeight: "700", color: "white", fontSize: { lg: "48px", md: "26px", sm: "22px", xs: "18px" } }}>Portfolio</Typography>
                    <Typography variant='p' sx={{ fontWeight: "600", color: "white", display: "flex", justifyContent: "center", alignItems: "center" }}><AddHomeOutlinedIcon sx={{ marginBottom: "3px", marginRight: "3px" }} /> Home / <span style={{ marginLeft: "4px", color: "#09aff4" }}>Portfolio</span></Typography>

                </Box>
            </Box>
            <Box sx={{ paddingY: "20px" }}>
                <PortfolioNavigation />
            </Box>
            <Box className="portfolio-bg" sx={{ marginY: "20px" }}>
                <Slider />
            </Box>
            <Box>
                <SocialSection />
            </Box>
            <Box>
                <ContactSection />
            </Box>
            <Box>
                <Footer />
            </Box>
        </Box>
    )
}

export default Portfolio
