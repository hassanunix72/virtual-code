import { Box, Container, Grid, Link, Typography } from '@mui/material'
import React from 'react'
import portfolioSection from "./../../assets/Rectangle 16.svg"
import SlidingImage from '../../components/SlidingImage'

const PortfolioSection2 = () => {
      return (
            <Container maxWidth={"xl"}>
                  {/* 1st Row */}
                  <Grid container sx={{ marginTop: "20px", }} spacing={6}>
                        <Grid item lg={3} md={6} sm={6} xs={12}>
                              <SlidingImage />
                        </Grid>
                        <Grid item lg={3} md={6} sm={6} xs={12}>
                              <SlidingImage />
                        </Grid>
                        <Grid item lg={3} md={6} sm={6} xs={12}>
                              <SlidingImage />
                        </Grid>
                        <Grid item lg={3} md={6} sm={6} xs={12}>
                              <SlidingImage />
                        </Grid>
                  </Grid>


                  {/* 2nd Row */}

                  <Grid container sx={{ marginTop: "1px", }} spacing={6}>
                        <Grid item lg={3} md={6} sm={6} xs={12}>
                              <SlidingImage />
                        </Grid>
                        <Grid item lg={3} md={6} sm={6} xs={12}>
                              <SlidingImage />
                        </Grid>
                        <Grid item lg={3} md={6} sm={6} xs={12}>
                              <SlidingImage />
                        </Grid>
                        <Grid item lg={3} md={6} sm={6} xs={12}>
                              <SlidingImage />
                        </Grid>
                  </Grid>
            </Container >
      )
}

export default PortfolioSection2
