import { Box, Typography } from '@mui/material'
import React from 'react'
import Navbar from '../Home/Navbar/Navber'
import AddHomeOutlinedIcon from '@mui/icons-material/AddHomeOutlined';
import PriceSection from '../Home/PriceSection/PriceSection';
import Slider from '../Home/TestimonialSection/Slider';
import SocialSection from '../Home/SocialSection/SocialSection';
import ContactSection from '../Home/ContactSection/ContactSection';
import Footer from '../Home/Footer/Footer';
const PricePlanSection = () => {
    return (
        <Box sx={{ bgcolor: "#181757" }} >
            <Box className="main3-bg" sx={{ height: { lg: "65vh", xs: "80%", md: "40vh" }, paddingBottom: "20px" }}>
                <Box><Navbar /></Box>
                <Box sx={{ textAlign: "center", marginY: "160px" }}>

                    <Typography variant='h3' sx={{ fontWeight: "bold", color: "white", fontSize: { lg: "48px", md: "26px", sm: "22px", xs: "18px" } }}>Pricing Plans</Typography>
                    <Typography variant='p' sx={{ fontWeight: "bold", color: "white", display: "flex", justifyContent: "center", alignItems: "center" }}><AddHomeOutlinedIcon sx={{ marginBottom: "3px", marginRight: "3px" }} /> Home / <span style={{ marginLeft: "3px", color: "#09aff4" }}>Pricing Plans    </span></Typography>

                </Box>
            </Box>
            <Box>
                <PriceSection />
            </Box>
            <Box className="portfolio-bg" sx={{ marginY: "20px" }}>
                <Slider />
            </Box>
            <Box sx={{ paddingY: "15px" }}>
                <SocialSection />
            </Box>
            <Box>
                <ContactSection />
            </Box>
            <Box>
                <Footer />
            </Box>
        </Box>
    )
}

export default PricePlanSection
