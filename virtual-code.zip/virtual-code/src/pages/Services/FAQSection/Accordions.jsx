import React from 'react';
import { Accordion, AccordionSummary, AccordionDetails, Box, Typography } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';

const Accordions = ({ accordionSummary, accordionDetails, expanded, onChange }) => {
    return (
        <Accordion
            expanded={expanded}
            onChange={onChange}
            sx={{
                bgcolor: "#181757",
                color: "#09aff4",
                borderBottom: "3px solid #09aff4",
                borderTop: expanded ? "4px solid #282777" : "",
                borderRight: expanded ? "4px solid #282777" : "",
                borderLeft: expanded ? "3px solid #282777" : "",
            }}
        >
            <AccordionSummary
                expandIcon={expanded ? <RemoveIcon color="primary" /> : <AddIcon color="primary" />}
                aria-controls="panel-content"
                id="panel-header"
                sx={{ fontWeight: "bold", fontSize: "17px" }}
            >
                {accordionSummary}
            </AccordionSummary>
            <AccordionDetails>
                <Box sx={{ marginX: "60px", color: "white", lineHeight: "20px" }}>
                    {accordionDetails}
                </Box>
            </AccordionDetails>
        </Accordion>
    );
};

export default Accordions;
