import React, { useState } from 'react';
import { Box, Container, Grid, Typography } from '@mui/material';
import Accordions from './Accordions';

export default function FAQSection() {
    const [expanded, setExpanded] = useState(null);

    const handleChange = (panel) => (event, isExpanded) => {
        setExpanded(isExpanded ? panel : null);
    };

    return (
        <Box sx={{ paddingY: "20px", }}>
            <Typography
                variant='h6'
                sx={{
                    color: "#09aff4",
                    fontWeight: "bold",
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    fontSize: { xs: "18px", md: "22px" }
                }}
            >
                <Box
                    component="span"
                    sx={{
                        fontSize: { xs: "20px", md: "25px" },
                        marginRight: "4px"
                    }}
                >
                    •
                </Box>
                BLOGS
                <Box
                    component="span"
                    sx={{
                        fontSize: { xs: "20px", md: "25px" },
                        marginLeft: "4px"
                    }}
                >
                    •
                </Box>
            </Typography>
            <Typography
                variant='h3'
                sx={{
                    fontWeight: "700",
                    fontSize: { xs: "24px", md: "36px", lg: "48px" },
                    marginY: { xs: "10px", md: "15px" },
                    textAlign: "center",
                    color: "white"
                }}
            >
                Frequently Asked Questions
            </Typography>
            <Container maxWidth={"xl"}>
                <Grid container>
                    <Grid item lg={6} md={12} sm={12} xs={12}>
                        <Box sx={{ padding: { lg: "20px", xs: "5px" } }}>
                            <Accordions
                                accordionSummary="Are Your Services Easy To Use?"
                                accordionDetails="Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eligendi?"
                                expanded={expanded === 'panel1'}
                                onChange={handleChange('panel1')}
                            />
                        </Box>
                    </Grid>
                    <Grid item lg={6} md={12} sm={12} xs={12}>
                        <Box sx={{ padding: { lg: "20px", xs: "5px" } }}>
                            <Accordions
                                accordionSummary="How Much Will I Pay?"
                                accordionDetails="Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias sint voluptatum omnis et magni tenetur."
                                expanded={expanded === 'panel2'}
                                onChange={handleChange('panel2')}
                            />
                        </Box>
                    </Grid>
                    <Grid item lg={6} md={12} sm={12} xs={12}>
                        <Box sx={{ padding: { lg: "20px", xs: "5px" } }}>
                            <Accordions
                                accordionSummary="Will I Receive Future Updates?"
                                accordionDetails="Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias sint voluptatum omnis et magni tenetur."
                                expanded={expanded === 'panel3'}
                                onChange={handleChange('panel3')}
                            />
                        </Box>
                    </Grid>
                    <Grid item lg={6} md={12} sm={12} xs={12}>
                        <Box sx={{ padding: { lg: "20px", xs: "5px" } }}>
                            <Accordions
                                accordionSummary="Are There Other Fees?"
                                accordionDetails="Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias sint voluptatum omnis et magni tenetur."
                                expanded={expanded === 'panel4'}
                                onChange={handleChange('panel4')}
                            />
                        </Box>
                    </Grid>
                    <Grid item lg={6} md={12} sm={12} xs={12}>
                        <Box sx={{ padding: { lg: "20px", xs: "5px" } }}>
                            <Accordions
                                accordionSummary="Does This Service Work In My Country?"
                                accordionDetails="Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias sint voluptatum omnis et magni tenetur."
                                expanded={expanded === 'panel5'}
                                onChange={handleChange('panel5')}
                            />
                        </Box>
                    </Grid>
                    <Grid item lg={6} md={12} sm={12} xs={12}>
                        <Box sx={{ padding: { lg: "20px", xs: "5px" } }}>
                            <Accordions
                                accordionSummary="How Can I Sign Up The Contract?"
                                accordionDetails="Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias sint voluptatum omnis et magni tenetur."
                                expanded={expanded === 'panel6'}
                                onChange={handleChange('panel6')}
                            />
                        </Box>
                    </Grid>
                </Grid>
            </Container>
        </Box>
    );
}
