import { Box, Container, Grid, Typography } from '@mui/material'
import React from 'react'
import CardCollection from '../../Home/Section1/CardCollection'
import Section2 from '../../Home/Section1/Section2'

const ServiceSection = () => {
  return (
    <Box sx={{ backgroundColor: "#181757", textAlign: "center", color: "white", minHeight: "100vh", maxHeight: "100%", paddingTop: "40px" }}>
    <Container maxWidth={"xl"} >
        <Grid container justifyContent="center" >
            <Grid item lg={6} >

                <Typography variant='h6' sx={{ color: "#09aff4", fontWeight: "bold", display: "flex", justifyContent: "center", alignItems: "center" }}>
                    <span style={{ fontSize: "25px", marginRight: "4px" }}>•</span>
                    Our Services
                    <span style={{ fontSize: "25px", marginLeft: "4px" }}>•</span>
                </Typography>


                <Typography variant='h3' sx={{ fontWeight: "700", margin: "10px 0", fontSize: { lg: "48px", sm: "30px", xs: "25px", md: "48px" } }}>Services We Offer

                </Typography>
                <Typography sx={{ fontSize: { lg: "15px", xs: "15px" }, textAlign: "center" }}>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sedarchitecto dolorum inventore totam adipisci</Typography>
            </Grid>
         
        </Grid>
        {/* Section Cards */}
        <Box sx={{ marginTop: "50px" }}>
            <CardCollection />
        </Box>

    </Container>
    {/* 2nd Section Start */}
    <Box marginTop={"50px"} >
        <Section2 />
    </Box>

    {/* 2nd Section End */}
</Box>
  )
}

export default ServiceSection
