import React from 'react'
import { Box, Fade, Typography } from '@mui/material'
import Navbar from '../Home/Navbar/Navber'
import AddHomeOutlinedIcon from '@mui/icons-material/AddHomeOutlined';
import ServiceSection from './ServiceSection/ServiceSection';
import SocialSection from '../Home/SocialSection/SocialSection';
import FAQSection from './FAQSection/FAQSection';
import Footer from '../Home/Footer/Footer';
import ContactSection from '../Home/ContactSection/ContactSection';
const Services = () => {
    return (
        <Box sx={{ bgcolor: "#181757", }}>
            <Box className="main3-bg" sx={{ height: { lg: "65vh", xs: "80%", md: "40vh" }, paddingBottom: "20px" }}>
                <Box><Navbar /></Box>
                <Fade in={true}>
                    <Box sx={{ textAlign: "center", marginY: { lg: "160px", xs: "100px" } }}>

                        <Typography variant='h3' sx={{ fontWeight: "bold", color: "white", fontSize: { lg: "46px", md: "26px", sm: "22px", xs: "18px" } }}>Services</Typography>
                        <Typography variant='p' sx={{ fontWeight: "bold", color: "white", display: "flex", justifyContent: "center", alignItems: "center" }}><AddHomeOutlinedIcon sx={{ marginBottom: "3px", marginRight: "3px" }} /> Home / <span style={{ marginLeft: "3px", color: "#09aff4" }}>Services</span></Typography>

                    </Box>
                </Fade>
            </Box>

            {/* Components */}
            <Box sx={{ bgcolor: "#181757", paddingY: { lg: "20px", sm: "20px", md: "30px", xs: "10px" } }}>
                <ServiceSection />
            </Box>
            <Box sx={{ paddingY: { lg: "80px", sm: "50px", md: "60px", xs: "30px" } }}>
                <SocialSection />
            </Box>
            <Box sx={{ marginY: { lg: "0px", sm: "80px", md: "60px", xs: "10px" } }}>
                <FAQSection />
            </Box>
            <Box sx={{ paddingTop: { lg: "0", sm: "100px", md: "180px", xs: "10px" } }}>
                <ContactSection />
            </Box>
            <Box >
                <Footer />
            </Box>
        </Box >
    )
}

export default Services
